﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP4_Milstead
{
    class Employee
    {
        //Fields to hold properties.
        private string _name;
        private int _idnum;
        private string _dept;
        private string _position;

        //Constructor with parameters.
        public Employee(string name, int idnum, string dept, string position)
        {
            _name = name;
            _idnum = idnum;
            _dept = dept;
            _position = position;
        }

        //Constructor with 2 parameters
        public Employee(string name, int idnum)
        {
            _name = name;
            _idnum = idnum;
            _dept = "";
            _position = "";
        }

        //Constructor with no parameters
        public Employee()
        {
            _name = "";
            _idnum = 0;
            _dept = "";
            _position = "";

        }

        //Name Property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        //ID Property
        public int ID
        {
            get { return _idnum; }
            set { _idnum = value; }
        }
        //Dept Property
        public string Dept
        {
            get { return _dept; }
            set { _dept = value; }
        }
        //Name Property
        public string Position
        {
            get { return _position; }
            set { _position = value; }
        }
    }
}