﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP4_Milstead
{
    public partial class Form1 : Form
    {
        //List to hold Employee objects.
        List<Employee> empList = new List<Employee>();
        public Form1()
        {
            InitializeComponent();
        }

        private void GetData(Employee emp)
        {
            //Get the employee's name.
            emp.Name = nameTextBox.Text;

            //Get the employee's idnumber.
            int id;
            if (int.TryParse(idTextBox.Text, out id))
                { emp.ID = id; }
            else
            { MessageBox.Show("Please enter a valid number for Employee ID"); }

            //Get the employee's department.
            emp.Dept = deptTextBox.Text;

            //Get the employee's position.
            emp.Position = posTextBox.Text;


        }

        private void addButton_Click(object sender, EventArgs e)
        {
            //Create an employee object.
            Employee emp = new Employee();

            //Get the employee data
            GetData(emp);

            //Add the Employee object to the list.
            empList.Add(emp);

            //Add an entry to the listbox.
            
            outputListBox.Items.Add(emp.Name + "\t" + emp.ID + "\t" + "\t" + emp.Dept + "\t"  +"\t" + emp.Position);

            //Clear the controls.
            nameTextBox.Clear();
            idTextBox.Clear();
            deptTextBox.Clear();
            posTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            outputListBox.Items.Add("Name" + "\t" + "ID Number" + "\t" + "Department" + "\t" + "Position");
        }
    }
}
