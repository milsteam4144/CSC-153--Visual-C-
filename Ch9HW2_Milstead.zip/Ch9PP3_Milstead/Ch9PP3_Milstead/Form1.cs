﻿/**
* Mallory Milstead
* CSC 153
* 5/7/2018
* This program creates an object from the Contacts class, adds it to a list that displays in a listbox. 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP3_Milstead
{
    public partial class Form1 : Form
    {
        //Create a field list to hold the Contacts class's objects...the <Contacts> means that all items in list must be Contacts objects
        List<Contacts> contactsList = new List<Contacts>();

        public Form1()
        {
            InitializeComponent();
        }

        //Allow the age textbox to only accept numbers. (Also, its set to a max of 3 digits)
        private void ageTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        //This method accepts a Contacts object as an argument. It assigns the user input to the object's properties. 
        //In the argument, (Contacts contact), Contacts means that the argument will be an object from the Contacts class and the contact is the name of the object(instance) of the class.
        private void GetContactData(Contacts contact)
        {
            //Get the contact's information from the user.
            contact.Name = nameTextBox.Text;
            contact.Address = addressTextBox.Text;
            contact.Age = Convert.ToInt32(ageTextBox.Text);
            contact.Phone = phoneTextBox.Text; 
           

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (nameTextBox.Text != "" && addressTextBox.Text != "" && ageTextBox.Text != "" && phoneTextBox.Text != "")
            { //Create an object from the Contacts class.
                Contacts newContact = new Contacts();

                //Get the object's data.
                GetContactData(newContact);

                //Add the object to the list.
                contactsList.Add(newContact);

                //Add an entry to the listbox.
                outputListBox.Items.Add(newContact.Name);

                //Clear the textboxes.
                nameTextBox.Clear();
                addressTextBox.Clear();
                ageTextBox.Clear();
                phoneTextBox.Clear();

                //Reset the focus.
                nameTextBox.Focus();
            }

            else

            { MessageBox.Show("Please complete all fields and try again"); }
        }

        private void outputListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Get the index of the selected item.
            int index = outputListBox.SelectedIndex;

            MessageBox.Show("Name: " + contactsList[index].Name + "\n" +
                          "Address: " + contactsList[index].Address + "\n" +
                          "Age: " + contactsList[index].Age + "\n" +
                          "Phone No.: " + contactsList[index].Phone);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }   
}
