﻿/**
* 2/6/2018
* CSC 153
* Mallory Milstead
* Program gets user input and calculates to determine miles driven per gallon of gas used.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculating_Fuel_Economy
{
    public partial class fuelEconomyform : Form
    {
        public fuelEconomyform()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles; //Initializes miles variable as a "double"
            double gallons; //Initializes gallons variable as a "double"
            double mpg; //Initializes mpg variable as a "double"

            //Get miles driven from user and assign it to miles variable.
            miles = double.Parse(milesTextBox.Text);

            //Get gallons used and assign it to gallons variable.
            gallons = double.Parse(gallonsTextBox.Text);

            //Calculate mpg.
            mpg = miles / gallons;

            //Display the mpg in the mpgLabel control.
            mpgLabel.Text = mpg.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
