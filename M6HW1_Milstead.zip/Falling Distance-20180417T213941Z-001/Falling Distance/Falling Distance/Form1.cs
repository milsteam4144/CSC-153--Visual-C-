﻿/**
* 4/12/2018
* CSC 153
* Mallory Milstead
* This program uses a method to ensure that user input is valid. The method returns a boolean value of true if the input is valid.
* valid input results in the data being stored in a variable, "time" which is then passed as an argument to the method.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class distanceForm : Form

    {
        //Constant field for Gravity variable.
        private const double G = 9.8;


        public distanceForm()
        {
            InitializeComponent();
        }

        private bool InputisValid(ref double time)
        {

            //Flag variable to indicate whether the input is good.
            bool inputGood = false;

            //If statement to determine if input can be parsed to a double.
            if (double.TryParse(inputTextBox.Text, out time))
            {
                inputGood = true;
            }
            else
            {
                //Display an error message for the TextBox.
                MessageBox.Show("The amount of time entered is invalid");
            }

            //Return the result.
            return inputGood;

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Variable for time and distance.
            double time = 0, distance = 0;

            if (InputisValid(ref time))
            {
                //Calculate the distance that the object has fallen.
                distance = .5 * G * (Math.Pow(time, 2));

                //Output the distance to the label.
                outputLabel.Text = distance.ToString();
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the textbox(input) and label(output).
            inputTextBox.Text = "";
            outputLabel.Text = "";
        }
    }
}

