﻿/**
* Mallory Milstead
* CSC 153
* 5/12/2018
* This program uses two forms to allow the user to select from radiobuttons and display their choices on a separate form.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Milstead
{
    public partial class selectForm : Form
    {
        public selectForm()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //Create an instance of the DisplayForm class.
            DisplayForm thisDisplayForm = new DisplayForm();

            //Create variables to hold the prices.
            int dormPrice = 0;
            int mealPrice = 0;

            //Find the selected radio button and assign the cooresponding text to the output label and the price to the variable.

            //Dorm radiobuttons.

            if (allenButton.Checked)
                {
                    thisDisplayForm.dormOutputLabel.Text = "Allen Hall";
                    dormPrice = 1500;

                }

                else if (pikeButton.Checked)
                {
                    thisDisplayForm.dormOutputLabel.Text = "Pike Hall";
                    dormPrice = 1600;
                }

                else if (farthingButton.Checked)
                {
                    thisDisplayForm.dormOutputLabel.Text = "Farthing Hall";
                    dormPrice = 1800;
                }

                else if (universityButton.Checked)
                {
                    thisDisplayForm.dormOutputLabel.Text = "University Suites";
                    dormPrice = 2500;
                }
            

           

                //Meal radiobuttons,

                if (meal7Button.Checked)
                {
                    thisDisplayForm.mealOutputLabel.Text = "Seven Meals";
                    mealPrice = 600;
                }

                else if (meal14Button.Checked)
                {
                    thisDisplayForm.mealOutputLabel.Text = "Fourteen Meals";
                    mealPrice = 1200;
                }

                else if (unlimitedMealsButton.Checked)
                {
                    thisDisplayForm.mealOutputLabel.Text = "Unlimited Meals";
                    mealPrice = 1700;
                }
            
            

            //Calculate the total.

            int totalPrice = dormPrice + mealPrice;

            //If the variables are not set to 0 ( if the user has make appropriate selections):

            if (dormPrice != 0 && mealPrice !=0)

            {   //Display the total after parsing to a string with the currency argument.
                thisDisplayForm.totalOutputLabel.Text = totalPrice.ToString("c");

                //Display the DisplayForm.
                thisDisplayForm.ShowDialog();

            }

            else
            //If the user has not made appropriate selections, show a messagebox.
            {
                MessageBox.Show("Please ensure a dormitory and meal plan are selected.");
            }

            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }

        
    }
}
