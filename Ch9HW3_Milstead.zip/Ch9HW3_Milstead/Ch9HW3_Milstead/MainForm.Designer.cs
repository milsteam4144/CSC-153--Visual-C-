﻿namespace Ch9HW3_Milstead
{
    partial class selectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormGroupBox = new System.Windows.Forms.GroupBox();
            this.universityButton = new System.Windows.Forms.RadioButton();
            this.farthingButton = new System.Windows.Forms.RadioButton();
            this.allenButton = new System.Windows.Forms.RadioButton();
            this.pikeButton = new System.Windows.Forms.RadioButton();
            this.mealGroupBox = new System.Windows.Forms.GroupBox();
            this.meal7Button = new System.Windows.Forms.RadioButton();
            this.meal14Button = new System.Windows.Forms.RadioButton();
            this.unlimitedMealsButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.dormGroupBox.SuspendLayout();
            this.mealGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dormGroupBox
            // 
            this.dormGroupBox.Controls.Add(this.universityButton);
            this.dormGroupBox.Controls.Add(this.farthingButton);
            this.dormGroupBox.Controls.Add(this.allenButton);
            this.dormGroupBox.Controls.Add(this.pikeButton);
            this.dormGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormGroupBox.Location = new System.Drawing.Point(35, 94);
            this.dormGroupBox.Name = "dormGroupBox";
            this.dormGroupBox.Size = new System.Drawing.Size(484, 203);
            this.dormGroupBox.TabIndex = 9;
            this.dormGroupBox.TabStop = false;
            this.dormGroupBox.Text = "Dormitories";
            // 
            // universityButton
            // 
            this.universityButton.AutoSize = true;
            this.universityButton.Location = new System.Drawing.Point(168, 151);
            this.universityButton.Name = "universityButton";
            this.universityButton.Size = new System.Drawing.Size(188, 19);
            this.universityButton.TabIndex = 12;
            this.universityButton.Text = "University Suites - $2,500";
            this.universityButton.UseVisualStyleBackColor = true;
            // 
            // farthingButton
            // 
            this.farthingButton.AutoSize = true;
            this.farthingButton.Location = new System.Drawing.Point(168, 111);
            this.farthingButton.Name = "farthingButton";
            this.farthingButton.Size = new System.Drawing.Size(165, 19);
            this.farthingButton.TabIndex = 11;
            this.farthingButton.Text = "Farthing Hall - $1,800";
            this.farthingButton.UseVisualStyleBackColor = true;
            // 
            // allenButton
            // 
            this.allenButton.AutoSize = true;
            this.allenButton.Location = new System.Drawing.Point(168, 32);
            this.allenButton.Name = "allenButton";
            this.allenButton.Size = new System.Drawing.Size(144, 19);
            this.allenButton.TabIndex = 10;
            this.allenButton.Text = "Allen Hall - $1,500";
            this.allenButton.UseVisualStyleBackColor = true;
            //is.allenButton.CheckedChanged += new System.EventHandler(this.allenButton_CheckedChanged);
            // 
            // pikeButton
            // 
            this.pikeButton.AutoSize = true;
            this.pikeButton.Location = new System.Drawing.Point(168, 74);
            this.pikeButton.Name = "pikeButton";
            this.pikeButton.Size = new System.Drawing.Size(140, 19);
            this.pikeButton.TabIndex = 9;
            this.pikeButton.Text = "Pike Hall - $1,600";
            this.pikeButton.UseVisualStyleBackColor = true;
            // 
            // mealGroupBox
            // 
            this.mealGroupBox.Controls.Add(this.meal7Button);
            this.mealGroupBox.Controls.Add(this.meal14Button);
            this.mealGroupBox.Controls.Add(this.unlimitedMealsButton);
            this.mealGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealGroupBox.Location = new System.Drawing.Point(35, 322);
            this.mealGroupBox.Name = "mealGroupBox";
            this.mealGroupBox.Size = new System.Drawing.Size(484, 196);
            this.mealGroupBox.TabIndex = 0;
            this.mealGroupBox.TabStop = false;
            this.mealGroupBox.Text = "Meals";
            // 
            // meal7Button
            // 
            this.meal7Button.AutoSize = true;
            this.meal7Button.Location = new System.Drawing.Point(168, 34);
            this.meal7Button.Name = "meal7Button";
            this.meal7Button.Size = new System.Drawing.Size(214, 19);
            this.meal7Button.TabIndex = 12;
            this.meal7Button.Text = "Seven meals per week - $600";
            this.meal7Button.UseVisualStyleBackColor = true;
            // 
            // meal14Button
            // 
            this.meal14Button.AutoSize = true;
            this.meal14Button.Location = new System.Drawing.Point(168, 92);
            this.meal14Button.Name = "meal14Button";
            this.meal14Button.Size = new System.Drawing.Size(244, 19);
            this.meal14Button.TabIndex = 11;
            this.meal14Button.Text = "Fourteen meals per week - $1,200";
            this.meal14Button.UseVisualStyleBackColor = true;
            // 
            // unlimitedMealsButton
            // 
            this.unlimitedMealsButton.AutoSize = true;
            this.unlimitedMealsButton.Location = new System.Drawing.Point(168, 150);
            this.unlimitedMealsButton.Name = "unlimitedMealsButton";
            this.unlimitedMealsButton.Size = new System.Drawing.Size(187, 19);
            this.unlimitedMealsButton.TabIndex = 10;
            this.unlimitedMealsButton.Text = "Unlimited meals - $1,700";
            this.unlimitedMealsButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(403, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Choose one dormitory and one meal plan:";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(120, 540);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(123, 59);
            this.submitButton.TabIndex = 13;
            this.submitButton.Text = "Submit Selections";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(161, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "(Prices are per semester)";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(282, 540);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(123, 59);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Close";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // selectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 627);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mealGroupBox);
            this.Controls.Add(this.dormGroupBox);
            this.Name = "selectForm";
            this.Text = "Dorm and Meal Plan";
            this.dormGroupBox.ResumeLayout(false);
            this.dormGroupBox.PerformLayout();
            this.mealGroupBox.ResumeLayout(false);
            this.mealGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox dormGroupBox;
        private System.Windows.Forms.GroupBox mealGroupBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton universityButton;
        private System.Windows.Forms.RadioButton farthingButton;
        private System.Windows.Forms.RadioButton allenButton;
        private System.Windows.Forms.RadioButton pikeButton;
        private System.Windows.Forms.RadioButton meal7Button;
        private System.Windows.Forms.RadioButton meal14Button;
        private System.Windows.Forms.RadioButton unlimitedMealsButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button exitButton;
    }
}

