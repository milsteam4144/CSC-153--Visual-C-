﻿namespace Sentence_Builder
{
    partial class sentenceBuilderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Abutton = new System.Windows.Forms.Button();
            this.a_Button = new System.Windows.Forms.Button();
            this.An_Button = new System.Windows.Forms.Button();
            this.an__Button = new System.Windows.Forms.Button();
            this.The_Button = new System.Windows.Forms.Button();
            this.man_Button = new System.Windows.Forms.Button();
            this.woman_Button = new System.Windows.Forms.Button();
            this.dog_Button = new System.Windows.Forms.Button();
            this.cat_Button = new System.Windows.Forms.Button();
            this.car_Button = new System.Windows.Forms.Button();
            this.beautiful_Button = new System.Windows.Forms.Button();
            this.big_Button = new System.Windows.Forms.Button();
            this.small_Button = new System.Windows.Forms.Button();
            this.strange_Button = new System.Windows.Forms.Button();
            this.lookedat_Button = new System.Windows.Forms.Button();
            this.the__Button = new System.Windows.Forms.Button();
            this.bicycle_Button = new System.Windows.Forms.Button();
            this.rode_Button = new System.Windows.Forms.Button();
            this.spoketo_Button = new System.Windows.Forms.Button();
            this.laughedat_Button = new System.Windows.Forms.Button();
            this.drove_Button = new System.Windows.Forms.Button();
            this.space_Button = new System.Windows.Forms.Button();
            this.period_Button = new System.Windows.Forms.Button();
            this.exclamation_Button = new System.Windows.Forms.Button();
            this.in_Button = new System.Windows.Forms.Button();
            this.displayLabel = new System.Windows.Forms.Label();
            this.clear_Button = new System.Windows.Forms.Button();
            this.exit_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Abutton
            // 
            this.Abutton.Location = new System.Drawing.Point(67, 45);
            this.Abutton.Name = "Abutton";
            this.Abutton.Size = new System.Drawing.Size(39, 25);
            this.Abutton.TabIndex = 0;
            this.Abutton.Text = "A";
            this.Abutton.UseVisualStyleBackColor = true;
            this.Abutton.Click += new System.EventHandler(this.Abutton_Click);
            // 
            // a_Button
            // 
            this.a_Button.Location = new System.Drawing.Point(152, 45);
            this.a_Button.Name = "a_Button";
            this.a_Button.Size = new System.Drawing.Size(35, 25);
            this.a_Button.TabIndex = 1;
            this.a_Button.Text = "a";
            this.a_Button.UseVisualStyleBackColor = true;
            this.a_Button.Click += new System.EventHandler(this.a_Button_Click);
            // 
            // An_Button
            // 
            this.An_Button.Location = new System.Drawing.Point(234, 45);
            this.An_Button.Name = "An_Button";
            this.An_Button.Size = new System.Drawing.Size(47, 25);
            this.An_Button.TabIndex = 2;
            this.An_Button.Text = "An";
            this.An_Button.UseVisualStyleBackColor = true;
            this.An_Button.Click += new System.EventHandler(this.An_Button_Click);
            // 
            // an__Button
            // 
            this.an__Button.Location = new System.Drawing.Point(323, 45);
            this.an__Button.Name = "an__Button";
            this.an__Button.Size = new System.Drawing.Size(46, 25);
            this.an__Button.TabIndex = 3;
            this.an__Button.Text = "an";
            this.an__Button.UseVisualStyleBackColor = true;
            this.an__Button.Click += new System.EventHandler(this.an__Button_Click);
            // 
            // The_Button
            // 
            this.The_Button.Location = new System.Drawing.Point(407, 45);
            this.The_Button.Name = "The_Button";
            this.The_Button.Size = new System.Drawing.Size(52, 25);
            this.The_Button.TabIndex = 4;
            this.The_Button.Text = "The";
            this.The_Button.UseVisualStyleBackColor = true;
            this.The_Button.Click += new System.EventHandler(this.The_Button_Click);
            // 
            // man_Button
            // 
            this.man_Button.Location = new System.Drawing.Point(67, 91);
            this.man_Button.Name = "man_Button";
            this.man_Button.Size = new System.Drawing.Size(66, 25);
            this.man_Button.TabIndex = 5;
            this.man_Button.Text = "man";
            this.man_Button.UseVisualStyleBackColor = true;
            this.man_Button.Click += new System.EventHandler(this.man_Button_Click);
            // 
            // woman_Button
            // 
            this.woman_Button.Location = new System.Drawing.Point(152, 91);
            this.woman_Button.Name = "woman_Button";
            this.woman_Button.Size = new System.Drawing.Size(66, 25);
            this.woman_Button.TabIndex = 6;
            this.woman_Button.Text = "woman";
            this.woman_Button.UseVisualStyleBackColor = true;
            this.woman_Button.Click += new System.EventHandler(this.woman_Button_Click);
            // 
            // dog_Button
            // 
            this.dog_Button.Location = new System.Drawing.Point(234, 91);
            this.dog_Button.Name = "dog_Button";
            this.dog_Button.Size = new System.Drawing.Size(66, 25);
            this.dog_Button.TabIndex = 7;
            this.dog_Button.Text = "dog";
            this.dog_Button.UseVisualStyleBackColor = true;
            this.dog_Button.Click += new System.EventHandler(this.dog_Button_Click);
            // 
            // cat_Button
            // 
            this.cat_Button.Location = new System.Drawing.Point(323, 91);
            this.cat_Button.Name = "cat_Button";
            this.cat_Button.Size = new System.Drawing.Size(66, 25);
            this.cat_Button.TabIndex = 8;
            this.cat_Button.Text = "cat";
            this.cat_Button.UseVisualStyleBackColor = true;
            this.cat_Button.Click += new System.EventHandler(this.cat_Button_Click);
            // 
            // car_Button
            // 
            this.car_Button.Location = new System.Drawing.Point(407, 91);
            this.car_Button.Name = "car_Button";
            this.car_Button.Size = new System.Drawing.Size(66, 25);
            this.car_Button.TabIndex = 9;
            this.car_Button.Text = "car";
            this.car_Button.UseVisualStyleBackColor = true;
            this.car_Button.Click += new System.EventHandler(this.car_Button_Click);
            // 
            // beautiful_Button
            // 
            this.beautiful_Button.Location = new System.Drawing.Point(121, 133);
            this.beautiful_Button.Name = "beautiful_Button";
            this.beautiful_Button.Size = new System.Drawing.Size(66, 24);
            this.beautiful_Button.TabIndex = 10;
            this.beautiful_Button.Text = "beautiful";
            this.beautiful_Button.UseVisualStyleBackColor = true;
            this.beautiful_Button.Click += new System.EventHandler(this.beautiful_Button_Click);
            // 
            // big_Button
            // 
            this.big_Button.Location = new System.Drawing.Point(215, 132);
            this.big_Button.Name = "big_Button";
            this.big_Button.Size = new System.Drawing.Size(66, 25);
            this.big_Button.TabIndex = 11;
            this.big_Button.Text = "big";
            this.big_Button.UseVisualStyleBackColor = true;
            this.big_Button.Click += new System.EventHandler(this.big_Button_Click);
            // 
            // small_Button
            // 
            this.small_Button.Location = new System.Drawing.Point(323, 132);
            this.small_Button.Name = "small_Button";
            this.small_Button.Size = new System.Drawing.Size(66, 25);
            this.small_Button.TabIndex = 12;
            this.small_Button.Text = "small";
            this.small_Button.UseVisualStyleBackColor = true;
            this.small_Button.Click += new System.EventHandler(this.small_Button_Click);
            // 
            // strange_Button
            // 
            this.strange_Button.Location = new System.Drawing.Point(420, 132);
            this.strange_Button.Name = "strange_Button";
            this.strange_Button.Size = new System.Drawing.Size(66, 25);
            this.strange_Button.TabIndex = 13;
            this.strange_Button.Text = "strange";
            this.strange_Button.UseVisualStyleBackColor = true;
            this.strange_Button.Click += new System.EventHandler(this.strange_Button_Click);
            // 
            // lookedat_Button
            // 
            this.lookedat_Button.Location = new System.Drawing.Point(67, 177);
            this.lookedat_Button.Name = "lookedat_Button";
            this.lookedat_Button.Size = new System.Drawing.Size(66, 25);
            this.lookedat_Button.TabIndex = 14;
            this.lookedat_Button.Text = "looked at";
            this.lookedat_Button.UseVisualStyleBackColor = true;
            this.lookedat_Button.Click += new System.EventHandler(this.lookedat_Button_Click);
            // 
            // the__Button
            // 
            this.the__Button.Location = new System.Drawing.Point(495, 45);
            this.the__Button.Name = "the__Button";
            this.the__Button.Size = new System.Drawing.Size(47, 25);
            this.the__Button.TabIndex = 15;
            this.the__Button.Text = "the";
            this.the__Button.UseVisualStyleBackColor = true;
            this.the__Button.Click += new System.EventHandler(this.the__Button_Click);
            // 
            // bicycle_Button
            // 
            this.bicycle_Button.Location = new System.Drawing.Point(495, 91);
            this.bicycle_Button.Name = "bicycle_Button";
            this.bicycle_Button.Size = new System.Drawing.Size(66, 25);
            this.bicycle_Button.TabIndex = 16;
            this.bicycle_Button.Text = "bicycle";
            this.bicycle_Button.UseVisualStyleBackColor = true;
            this.bicycle_Button.Click += new System.EventHandler(this.bicycle_Button_Click);
            // 
            // rode_Button
            // 
            this.rode_Button.Location = new System.Drawing.Point(152, 177);
            this.rode_Button.Name = "rode_Button";
            this.rode_Button.Size = new System.Drawing.Size(66, 25);
            this.rode_Button.TabIndex = 17;
            this.rode_Button.Text = "rode";
            this.rode_Button.UseVisualStyleBackColor = true;
            this.rode_Button.Click += new System.EventHandler(this.rode_Button_Click);
            // 
            // spoketo_Button
            // 
            this.spoketo_Button.Location = new System.Drawing.Point(323, 177);
            this.spoketo_Button.Name = "spoketo_Button";
            this.spoketo_Button.Size = new System.Drawing.Size(66, 25);
            this.spoketo_Button.TabIndex = 18;
            this.spoketo_Button.Text = "spoke to";
            this.spoketo_Button.UseVisualStyleBackColor = true;
            this.spoketo_Button.Click += new System.EventHandler(this.spoketo_Button_Click);
            // 
            // laughedat_Button
            // 
            this.laughedat_Button.Location = new System.Drawing.Point(407, 177);
            this.laughedat_Button.Name = "laughedat_Button";
            this.laughedat_Button.Size = new System.Drawing.Size(66, 25);
            this.laughedat_Button.TabIndex = 19;
            this.laughedat_Button.Text = "laughed at";
            this.laughedat_Button.UseVisualStyleBackColor = true;
            this.laughedat_Button.Click += new System.EventHandler(this.laughedat_Button_Click);
            // 
            // drove_Button
            // 
            this.drove_Button.Location = new System.Drawing.Point(495, 177);
            this.drove_Button.Name = "drove_Button";
            this.drove_Button.Size = new System.Drawing.Size(66, 25);
            this.drove_Button.TabIndex = 20;
            this.drove_Button.Text = "drove";
            this.drove_Button.UseVisualStyleBackColor = true;
            this.drove_Button.Click += new System.EventHandler(this.drove_Button_Click);
            // 
            // space_Button
            // 
            this.space_Button.Location = new System.Drawing.Point(204, 223);
            this.space_Button.Name = "space_Button";
            this.space_Button.Size = new System.Drawing.Size(66, 25);
            this.space_Button.TabIndex = 21;
            this.space_Button.Text = "(Space)";
            this.space_Button.UseVisualStyleBackColor = true;
            this.space_Button.Click += new System.EventHandler(this.space_Button_Click);
            // 
            // period_Button
            // 
            this.period_Button.Location = new System.Drawing.Point(296, 223);
            this.period_Button.Name = "period_Button";
            this.period_Button.Size = new System.Drawing.Size(39, 25);
            this.period_Button.TabIndex = 22;
            this.period_Button.Text = ".";
            this.period_Button.UseVisualStyleBackColor = true;
            this.period_Button.Click += new System.EventHandler(this.period_Button_Click);
            // 
            // exclamation_Button
            // 
            this.exclamation_Button.Location = new System.Drawing.Point(365, 223);
            this.exclamation_Button.Name = "exclamation_Button";
            this.exclamation_Button.Size = new System.Drawing.Size(42, 25);
            this.exclamation_Button.TabIndex = 23;
            this.exclamation_Button.Text = "!";
            this.exclamation_Button.UseVisualStyleBackColor = true;
            this.exclamation_Button.Click += new System.EventHandler(this.exclamation_Button_Click);
            // 
            // in_Button
            // 
            this.in_Button.Location = new System.Drawing.Point(234, 177);
            this.in_Button.Name = "in_Button";
            this.in_Button.Size = new System.Drawing.Size(66, 25);
            this.in_Button.TabIndex = 24;
            this.in_Button.Text = "in";
            this.in_Button.UseVisualStyleBackColor = true;
            this.in_Button.Click += new System.EventHandler(this.in_Button_Click);
            // 
            // displayLabel
            // 
            this.displayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(12, 286);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(609, 56);
            this.displayLabel.TabIndex = 25;
            this.displayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clear_Button
            // 
            this.clear_Button.Location = new System.Drawing.Point(166, 366);
            this.clear_Button.Name = "clear_Button";
            this.clear_Button.Size = new System.Drawing.Size(104, 42);
            this.clear_Button.TabIndex = 26;
            this.clear_Button.Text = "Clear";
            this.clear_Button.UseVisualStyleBackColor = true;
            this.clear_Button.Click += new System.EventHandler(this.clear_Button_Click);
            // 
            // exit_Button
            // 
            this.exit_Button.Location = new System.Drawing.Point(323, 366);
            this.exit_Button.Name = "exit_Button";
            this.exit_Button.Size = new System.Drawing.Size(104, 42);
            this.exit_Button.TabIndex = 27;
            this.exit_Button.Text = "Exit";
            this.exit_Button.UseVisualStyleBackColor = true;
            this.exit_Button.Click += new System.EventHandler(this.exit_Button_Click);
            // 
            // sentenceBuilderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 430);
            this.Controls.Add(this.exit_Button);
            this.Controls.Add(this.clear_Button);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.in_Button);
            this.Controls.Add(this.exclamation_Button);
            this.Controls.Add(this.period_Button);
            this.Controls.Add(this.space_Button);
            this.Controls.Add(this.drove_Button);
            this.Controls.Add(this.laughedat_Button);
            this.Controls.Add(this.spoketo_Button);
            this.Controls.Add(this.rode_Button);
            this.Controls.Add(this.bicycle_Button);
            this.Controls.Add(this.the__Button);
            this.Controls.Add(this.lookedat_Button);
            this.Controls.Add(this.strange_Button);
            this.Controls.Add(this.small_Button);
            this.Controls.Add(this.big_Button);
            this.Controls.Add(this.beautiful_Button);
            this.Controls.Add(this.car_Button);
            this.Controls.Add(this.cat_Button);
            this.Controls.Add(this.dog_Button);
            this.Controls.Add(this.woman_Button);
            this.Controls.Add(this.man_Button);
            this.Controls.Add(this.The_Button);
            this.Controls.Add(this.an__Button);
            this.Controls.Add(this.An_Button);
            this.Controls.Add(this.a_Button);
            this.Controls.Add(this.Abutton);
            this.Name = "sentenceBuilderForm";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Abutton;
        private System.Windows.Forms.Button a_Button;
        private System.Windows.Forms.Button An_Button;
        private System.Windows.Forms.Button an__Button;
        private System.Windows.Forms.Button The_Button;
        private System.Windows.Forms.Button man_Button;
        private System.Windows.Forms.Button woman_Button;
        private System.Windows.Forms.Button dog_Button;
        private System.Windows.Forms.Button cat_Button;
        private System.Windows.Forms.Button car_Button;
        private System.Windows.Forms.Button beautiful_Button;
        private System.Windows.Forms.Button big_Button;
        private System.Windows.Forms.Button small_Button;
        private System.Windows.Forms.Button strange_Button;
        private System.Windows.Forms.Button lookedat_Button;
        private System.Windows.Forms.Button the__Button;
        private System.Windows.Forms.Button bicycle_Button;
        private System.Windows.Forms.Button rode_Button;
        private System.Windows.Forms.Button spoketo_Button;
        private System.Windows.Forms.Button laughedat_Button;
        private System.Windows.Forms.Button drove_Button;
        private System.Windows.Forms.Button space_Button;
        private System.Windows.Forms.Button period_Button;
        private System.Windows.Forms.Button exclamation_Button;
        private System.Windows.Forms.Button in_Button;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Button clear_Button;
        private System.Windows.Forms.Button exit_Button;
    }
}

