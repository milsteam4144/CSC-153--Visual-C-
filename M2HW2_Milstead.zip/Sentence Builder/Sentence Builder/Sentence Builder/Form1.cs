﻿/**
* 2/15/2018
* CSC 153
* Mallory Milstead
* This program allows user to create a sentence by clicking buttons and displays the sentence.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder
{
    public partial class sentenceBuilderForm : Form
    {
        //Initialize the field variable for the sentence. It will hold all of the text to be displayed.
        private string sentence = " ";
        public sentenceBuilderForm()
        {
            InitializeComponent();
        }
        /*The following click events add the text to the sentence object
         * Then they display the sentence in the displayLabel.
         **/
        private void Abutton_Click(object sender, EventArgs e)
        {
            sentence += "A";
            displayLabel.Text = sentence;
        }

        private void a_Button_Click(object sender, EventArgs e)
        {
            sentence += "a";
            displayLabel.Text = sentence;
        }

        private void An_Button_Click(object sender, EventArgs e)
        {
            sentence += "An";
            displayLabel.Text = sentence;
        }

        private void an__Button_Click(object sender, EventArgs e)
        {
            sentence += "an";
            displayLabel.Text = sentence;
        }

        private void The_Button_Click(object sender, EventArgs e)
        {
            sentence += "The";
            displayLabel.Text = sentence;
        }

        private void the__Button_Click(object sender, EventArgs e)
        {
            sentence += "the";
            displayLabel.Text = sentence;
        }

        private void man_Button_Click(object sender, EventArgs e)
        {
            sentence += "man";
            displayLabel.Text = sentence;
        }

        private void woman_Button_Click(object sender, EventArgs e)
        {
            sentence += "woman";
            displayLabel.Text = sentence;
        }

        private void dog_Button_Click(object sender, EventArgs e)
        {
            sentence += "dog";
            displayLabel.Text = sentence;
        }

        private void cat_Button_Click(object sender, EventArgs e)
        {
            sentence += "cat";
            displayLabel.Text = sentence;
        }

        private void car_Button_Click(object sender, EventArgs e)
        {
            sentence += "car";
            displayLabel.Text = sentence;
        }

        private void bicycle_Button_Click(object sender, EventArgs e)
        {
            sentence += "bicycle";
            displayLabel.Text = sentence;
        }

        private void beautiful_Button_Click(object sender, EventArgs e)
        {
            sentence += "beautiful";
            displayLabel.Text = sentence;
        }

        private void big_Button_Click(object sender, EventArgs e)
        {
            sentence += "big";
            displayLabel.Text = sentence;
        }

        private void small_Button_Click(object sender, EventArgs e)
        {
            sentence += "small";
            displayLabel.Text = sentence;
        }

        private void strange_Button_Click(object sender, EventArgs e)
        {
            sentence += "strange";
            displayLabel.Text = sentence;
        }

        private void lookedat_Button_Click(object sender, EventArgs e)
        {
            sentence += "looked at";
            displayLabel.Text = sentence;
        }

        private void rode_Button_Click(object sender, EventArgs e)
        {
            sentence += "rode";
            displayLabel.Text = sentence;
        }

        private void in_Button_Click(object sender, EventArgs e)
        {
            sentence += "in";
            displayLabel.Text = sentence;
        }

        private void spoketo_Button_Click(object sender, EventArgs e)
        {
            sentence += "spoke to";
            displayLabel.Text = sentence;
        }

        private void laughedat_Button_Click(object sender, EventArgs e)
        {
            sentence += "laughed at";
            displayLabel.Text = sentence;
        }

        private void drove_Button_Click(object sender, EventArgs e)
        {
            sentence += "drove";
            displayLabel.Text = sentence;
        }

        private void space_Button_Click(object sender, EventArgs e)
        {
            sentence += " ";
            displayLabel.Text = sentence;
        }

        private void period_Button_Click(object sender, EventArgs e)
        {
            sentence += ".";
            displayLabel.Text = sentence;
        }

        private void exclamation_Button_Click(object sender, EventArgs e)
        {
            sentence += "!";
            displayLabel.Text = sentence;
        }

        private void clear_Button_Click(object sender, EventArgs e)
        {
            //Clears the displayLabel.
            displayLabel.Text = "";
            //Reassigns the sentence variable to " ". (Clears it)
            sentence = "";
        }

        private void exit_Button_Click(object sender, EventArgs e)
        {
            //Closes the form
            this.Close();
        }
    }
}
