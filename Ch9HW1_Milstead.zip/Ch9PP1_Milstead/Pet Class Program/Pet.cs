﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Class_Program
{
    class Pet
    { //Field for the pet's name, type and age (properties).
        private string _name;
        private string _type;
        private double _age;

        //Constructors to initialize properties
        public Pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        //Get and set name property
        public string Name
        {
            get { return _name; }

            set { _name = value; }

        }

        public string Type
        {
            get { return _type; }

            set { _type = value; }

        }

        public double Age
        {
            get { return _age; }

            set { _age = value; }

        }
    }
}

