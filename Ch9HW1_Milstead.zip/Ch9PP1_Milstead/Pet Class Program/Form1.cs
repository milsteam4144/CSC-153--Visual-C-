﻿/**
* 5/3/2018
* CSC 153
* Mallory Milstead
* This program accepts user input and assigns it to properties from the Pet Class. It then displays the value of the properites.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class_Program
{
    public partial class petForm : Form
    {
        public petForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Create a Pet object.
            Pet myPet = new Pet();

            //Assign user input to the Name property.
            if (nameTextBox.Text != "")
            { myPet.Name = nameTextBox.Text; }
            else {MessageBox.Show("Please enter a name for your pet"); }

            //Assign user input to the Type property.
            if (typeTextBox.Text != "")
            //Convert the string to lowercase.
            {myPet.Type = typeTextBox.Text.ToLower(); }
            else { MessageBox.Show("Please enter a type for your pet"); }


            //If the textboxes are not empty:
            if (nameTextBox.Text != "" && typeTextBox.Text != "" && ageTextBox.Text != "")
            
            {
                //..and if the data in the age textbox can be parsed to a double...
                double age; //Initialize variable to hold age
                if (double.TryParse(ageTextBox.Text, out age))

                { 
                    //Assign the double to the Age property.
                    myPet.Age = age;
                    //Output the data to the label
                    outputLabel.Text = (myPet.Name + ", the " + myPet.Type + " is " + myPet.Age + " years old!");
                }
                //MessageBox-user input is not a valid double
                else { MessageBox.Show("Please enter a valid number for your pet's age"); }
            }

            //MessageBox-There is an empty textbox on the form.
            else { MessageBox.Show("Please ensure you have entered data for all fields"); }


        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the textboxes and the label.
            nameTextBox.Clear();
            typeTextBox.Clear();
            ageTextBox.Clear();
            outputLabel.Text = "";


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
