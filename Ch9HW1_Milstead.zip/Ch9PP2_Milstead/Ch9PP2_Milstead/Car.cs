﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP2_Milstead
{
    class Car
    {
        //Field for the car's properties
        private string _make;
        private int _year;
        private int _speed;
    

        //Constructors
        public Car()
        {
            _make = "";
            _year = 0;
            _speed = 0;

        }

        //Make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        //Year property
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        //Speed property
        public int Speed
        {
            get { return _speed; }
           
        }

        //Accelerate Method
        public void Accelerate()
        {
            _speed += 5;
        }

        //Brake Method
        public void Brake()
        {
            _speed -= 5;
        }

    }

}
