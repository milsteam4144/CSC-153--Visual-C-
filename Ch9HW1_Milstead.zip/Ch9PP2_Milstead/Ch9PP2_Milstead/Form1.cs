﻿/**
* 5/7/2018
* CSC 153
* Mallory Milstead
* This program uses a class called Car with the brake and accelerate methods to calculate and display the Speed property of a Car object.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP2_Milstead
{
    public partial class carForm : Form

    {
        //Declare a field variable to hold the object.

        private Car myCar = new Car();

        public carForm()
        {
            InitializeComponent();
        }

        private void carForm_Load(object sender, EventArgs e)
        {

            //Modify colors of label text when form loads.
            label2.ForeColor = Color.Red;
            label3.ForeColor = Color.Red;
            carLabel.ForeColor = Color.Red;
            speedLabel.ForeColor = Color.Red;
            //When form loads, the speed Label will show the default(constructor) value of the Speed property.
            speedLabel.Text = myCar.Speed.ToString();
           
        }

        private void accButton_Click(object sender, EventArgs e)
        {
            //If the year and model textboxes are not blank, call the accelerate method.
            if (makeTextBox.Text != "" && yearlTextBox.Text != "") 
            { myCar.Accelerate();
                speedLabel.Text = myCar.Speed.ToString(); }

            //If the year and model textboxes are blank, show a messagebox.
            else { MessageBox.Show("Enter a valid year and make for the car."); }
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            //If the user input in the year textbox can be parsed to an int, assign(out) that value to the variable year.
            if (int.TryParse(yearlTextBox.Text, out int year))
            {
                //AND if the make textbox is not blank, assign the values in the variable and textbox to the object's respective properties.
                if (makeTextBox.Text != "")
                {
                    myCar.Year = year;
                    myCar.Make = makeTextBox.Text;
                    //Print the string including the attributes to the label.
                    carLabel.Text = "The " + myCar.Year + " " + myCar.Make + " is going: ";
                }
                //If the maketextbox is blank, show this messagebox.
                else
                {
                    MessageBox.Show("Please enter a make for the car.");
                }
            }
            //If the user input in the yeartextbox cannot be parsed into an int, show this messagebox.
            else
                {
                    MessageBox.Show("Please enter a valid year for the car.");
                }
            }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            
            //If the make and year text boxes are not blank....
            if (makeTextBox.Text != "" && yearlTextBox.Text != "")
            //Call the brake method.
            { myCar.Brake(); }
            //If the text boxes are blank, show this messagebox.
            else { MessageBox.Show("Enter a valid year and make for the car."); }

                //If the value of the attribute, Speed, is less than zero, show the messagebox.
                if (myCar.Speed < 0)
                { MessageBox.Show("The speed cannot be negative"); }
            //If Speed >= 0, display the Speed property in the label.
            else
            { speedLabel.Text = myCar.Speed.ToString(); }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear textboxes and reset speedometer(speedlabel)
            yearlTextBox.Text = "";
            makeTextBox.Text = "";
            speedLabel.Text = "0";
            carLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form.
            this.Close();
        }
    }
    }

