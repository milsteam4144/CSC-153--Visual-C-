﻿namespace Heads_or_Tails_Application
{
    partial class headsOrtailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showHeadsbutton = new System.Windows.Forms.Button();
            this.showTailsbutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.tailsPicturebox = new System.Windows.Forms.PictureBox();
            this.headsPicturebox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsPicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // showHeadsbutton
            // 
            this.showHeadsbutton.Location = new System.Drawing.Point(62, 205);
            this.showHeadsbutton.Name = "showHeadsbutton";
            this.showHeadsbutton.Size = new System.Drawing.Size(102, 57);
            this.showHeadsbutton.TabIndex = 0;
            this.showHeadsbutton.Text = "Show Heads";
            this.showHeadsbutton.UseVisualStyleBackColor = true;
            this.showHeadsbutton.Click += new System.EventHandler(this.showHeadsbutton_Click);
            // 
            // showTailsbutton
            // 
            this.showTailsbutton.Location = new System.Drawing.Point(216, 205);
            this.showTailsbutton.Name = "showTailsbutton";
            this.showTailsbutton.Size = new System.Drawing.Size(99, 57);
            this.showTailsbutton.TabIndex = 1;
            this.showTailsbutton.Text = "Show Tails";
            this.showTailsbutton.UseVisualStyleBackColor = true;
            this.showTailsbutton.Click += new System.EventHandler(this.showTailsbutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(363, 205);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 57);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // tailsPicturebox
            // 
            this.tailsPicturebox.Image = global::Heads_or_Tails_Application.Properties.Resources.Tails2;
            this.tailsPicturebox.Location = new System.Drawing.Point(300, 31);
            this.tailsPicturebox.Name = "tailsPicturebox";
            this.tailsPicturebox.Size = new System.Drawing.Size(153, 146);
            this.tailsPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tailsPicturebox.TabIndex = 4;
            this.tailsPicturebox.TabStop = false;
            this.tailsPicturebox.Visible = false;
            // 
            // headsPicturebox
            // 
            this.headsPicturebox.Image = global::Heads_or_Tails_Application.Properties.Resources.Heads2;
            this.headsPicturebox.Location = new System.Drawing.Point(62, 31);
            this.headsPicturebox.Name = "headsPicturebox";
            this.headsPicturebox.Size = new System.Drawing.Size(152, 146);
            this.headsPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headsPicturebox.TabIndex = 3;
            this.headsPicturebox.TabStop = false;
            this.headsPicturebox.Visible = false;
            // 
            // headsOrtailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 320);
            this.Controls.Add(this.tailsPicturebox);
            this.Controls.Add(this.headsPicturebox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showTailsbutton);
            this.Controls.Add(this.showHeadsbutton);
            this.Name = "headsOrtailsForm";
            this.Text = "Heads or Tails";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsPicturebox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showHeadsbutton;
        private System.Windows.Forms.Button showTailsbutton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox headsPicturebox;
        private System.Windows.Forms.PictureBox tailsPicturebox;
    }
}

