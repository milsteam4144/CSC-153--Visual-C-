﻿/**
* 1/29/2018
* CSC 153-0051
* Kenneth Kleiner, Mallory Milstead, Anthony O'Brien (Group 3)
* Heads or Tails Program- Shows the images of a coin's heads or tails side using the respective buttons
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Heads_or_Tails_Application
{
    public partial class headsOrtailsForm : Form
    {
        public headsOrtailsForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void showHeadsbutton_Click(object sender, EventArgs e)
        {
            headsPicturebox.Visible = true;
            tailsPicturebox.Visible = false;

        }

        private void showTailsbutton_Click(object sender, EventArgs e)
        {

            headsPicturebox.Visible = false;
            tailsPicturebox.Visible = true;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
