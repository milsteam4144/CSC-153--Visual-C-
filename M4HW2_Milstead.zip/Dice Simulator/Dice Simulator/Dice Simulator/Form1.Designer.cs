﻿namespace Dice_Simulator
{
    partial class diceSimulator_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(diceSimulator_Form));
            this.roll_Button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.die2_PictureBox = new System.Windows.Forms.PictureBox();
            this.die1_PictureBox = new System.Windows.Forms.PictureBox();
            this.dieImageList = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.die2_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1_PictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // roll_Button
            // 
            this.roll_Button.Location = new System.Drawing.Point(53, 209);
            this.roll_Button.Name = "roll_Button";
            this.roll_Button.Size = new System.Drawing.Size(117, 60);
            this.roll_Button.TabIndex = 0;
            this.roll_Button.Text = "Roll Dice";
            this.roll_Button.UseVisualStyleBackColor = true;
            this.roll_Button.Click += new System.EventHandler(this.roll_Button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(230, 209);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(117, 60);
            this.exit_button.TabIndex = 1;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // die2_PictureBox
            // 
            this.die2_PictureBox.Image = global::Dice_Simulator.Properties.Resources.Die1;
            this.die2_PictureBox.Location = new System.Drawing.Point(230, 48);
            this.die2_PictureBox.Name = "die2_PictureBox";
            this.die2_PictureBox.Size = new System.Drawing.Size(128, 125);
            this.die2_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.die2_PictureBox.TabIndex = 8;
            this.die2_PictureBox.TabStop = false;
            this.die2_PictureBox.Visible = false;
            // 
            // die1_PictureBox
            // 
            this.die1_PictureBox.Image = global::Dice_Simulator.Properties.Resources.Die1;
            this.die1_PictureBox.Location = new System.Drawing.Point(38, 48);
            this.die1_PictureBox.Name = "die1_PictureBox";
            this.die1_PictureBox.Size = new System.Drawing.Size(132, 125);
            this.die1_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.die1_PictureBox.TabIndex = 2;
            this.die1_PictureBox.TabStop = false;
            this.die1_PictureBox.Visible = false;
            // 
            // dieImageList
            // 
            this.dieImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("dieImageList.ImageStream")));
            this.dieImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.dieImageList.Images.SetKeyName(0, "Die1.bmp");
            this.dieImageList.Images.SetKeyName(1, "Die2.bmp");
            this.dieImageList.Images.SetKeyName(2, "Die3.bmp");
            this.dieImageList.Images.SetKeyName(3, "Die4.bmp");
            this.dieImageList.Images.SetKeyName(4, "Die5.bmp");
            this.dieImageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // diceSimulator_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 291);
            this.Controls.Add(this.die2_PictureBox);
            this.Controls.Add(this.die1_PictureBox);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.roll_Button);
            this.Name = "diceSimulator_Form";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.die2_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1_PictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button roll_Button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.PictureBox die1_PictureBox;
        private System.Windows.Forms.PictureBox die2_PictureBox;
        private System.Windows.Forms.ImageList dieImageList;
    }
}

