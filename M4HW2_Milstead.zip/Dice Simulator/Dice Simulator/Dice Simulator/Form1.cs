﻿/**
* 3/19/2018
* CSC 153
* Mallory Milstead
* This program generates a random number(index) and displays the image (from an ImageList) that matches that index.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class diceSimulator_Form : Form
    {
        public diceSimulator_Form()
        {
            InitializeComponent();
        }

        private void roll_Button_Click(object sender, EventArgs e)
        {
            //Initialize variables to represent indexes of images in the ImageList.
            int index, index2;

            //Create a Random object.
            Random rand = new Random();

            //Assign variables to a random value from the number or "count" of images in the dieImageList.
            index = rand.Next(dieImageList.Images.Count);
            index2 = rand.Next(dieImageList.Images.Count);

            //Set the images in the picturebox to the image that matches that index in the ImageList.
            die1_PictureBox.Image = dieImageList.Images[index];
            die2_PictureBox.Image = dieImageList.Images[index2];

            //Dice are not visible when program starts, make them visible after user clicks button.
            die1_PictureBox.Visible = true;
            die2_PictureBox.Visible = true;

        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
