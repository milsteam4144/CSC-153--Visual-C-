﻿/**
* 3/20/2018
* CSC 153
* Milstead, Miller, Kleiner
* This program uses OpenFileDialog to allow the user to open a file, reads the data, performs calculations on the data and displays the data in a listbox.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void open_Button_Click(object sender, EventArgs e)
        {
            //Declare variables and accumulator.
            string nums; int intnums, counter, total=0;

            //Create a StreamReader variable.
            StreamReader inputFile;

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                //Open the selected file.
                inputFile = File.OpenText(openFile.FileName);

                //Clear anything in the listbox.
                display_ListBox.Items.Clear();

                //Read the file's contents.
                while (!inputFile.EndOfStream)
                {
                    //Assign the contents to a variable.
                    nums = inputFile.ReadLine();

                    //Display the file's contents in the listbox.
                    display_ListBox.Items.Add(nums);

                    //If the data from the file can be parsed to an int, continue.
                    if (int.TryParse(nums, out intnums))
                    {
                        //Add the integers to total.
                        total += intnums;
                    }

                    else
                    {
                        //If the data cannot be parsed to an int, show a messagebox.
                        MessageBox.Show("The file does not contain valid integers.");
                        break;
                    }
                }
             
                    //Use the Items.Count property and assign that value to a variable.
                    counter = display_ListBox.Items.Count;

                    //Display the count of items in the listbox.
                    display_ListBox.Items.Add("There are " + counter + " numbers in the file.");

                    //Display the total of the numbers.
                    display_ListBox.Items.Add("The total of the numbers is " + total);  
            }

            else
            {
                MessageBox.Show("No file opened.");
            }
        }

        private void exit_Button_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
