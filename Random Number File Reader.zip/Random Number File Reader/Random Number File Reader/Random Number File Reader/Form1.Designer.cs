﻿namespace Random_Number_File_Reader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.open_Button = new System.Windows.Forms.Button();
            this.exit_Button = new System.Windows.Forms.Button();
            this.display_ListBox = new System.Windows.Forms.ListBox();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // open_Button
            // 
            this.open_Button.Location = new System.Drawing.Point(66, 466);
            this.open_Button.Name = "open_Button";
            this.open_Button.Size = new System.Drawing.Size(92, 43);
            this.open_Button.TabIndex = 0;
            this.open_Button.Text = "Open File";
            this.open_Button.UseVisualStyleBackColor = true;
            this.open_Button.Click += new System.EventHandler(this.open_Button_Click);
            // 
            // exit_Button
            // 
            this.exit_Button.Location = new System.Drawing.Point(218, 466);
            this.exit_Button.Name = "exit_Button";
            this.exit_Button.Size = new System.Drawing.Size(95, 43);
            this.exit_Button.TabIndex = 1;
            this.exit_Button.Text = "Exit";
            this.exit_Button.UseVisualStyleBackColor = true;
            this.exit_Button.Click += new System.EventHandler(this.exit_Button_Click);
            // 
            // display_ListBox
            // 
            this.display_ListBox.FormattingEnabled = true;
            this.display_ListBox.Location = new System.Drawing.Point(66, 12);
            this.display_ListBox.Name = "display_ListBox";
            this.display_ListBox.Size = new System.Drawing.Size(247, 433);
            this.display_ListBox.TabIndex = 2;
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 521);
            this.Controls.Add(this.display_ListBox);
            this.Controls.Add(this.exit_Button);
            this.Controls.Add(this.open_Button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button open_Button;
        private System.Windows.Forms.Button exit_Button;
        private System.Windows.Forms.ListBox display_ListBox;
        private System.Windows.Forms.OpenFileDialog openFile;
    }
}

