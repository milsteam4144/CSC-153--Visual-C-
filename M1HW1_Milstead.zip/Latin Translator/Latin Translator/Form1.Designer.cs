﻿namespace Latin_Translator
{
    partial class latinTranslatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.thisIsEnglishLabel = new System.Windows.Forms.Label();
            this.translationLabel = new System.Windows.Forms.Label();
            this.sinisterButton = new System.Windows.Forms.Button();
            this.dexterButton = new System.Windows.Forms.Button();
            this.mediumButton = new System.Windows.Forms.Button();
            this.clickForEnglishLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // thisIsEnglishLabel
            // 
            this.thisIsEnglishLabel.AutoSize = true;
            this.thisIsEnglishLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thisIsEnglishLabel.Location = new System.Drawing.Point(167, 36);
            this.thisIsEnglishLabel.Name = "thisIsEnglishLabel";
            this.thisIsEnglishLabel.Size = new System.Drawing.Size(188, 16);
            this.thisIsEnglishLabel.TabIndex = 0;
            this.thisIsEnglishLabel.Text = "This is the English Translation:";
            // 
            // translationLabel
            // 
            this.translationLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.translationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.translationLabel.Location = new System.Drawing.Point(140, 68);
            this.translationLabel.Name = "translationLabel";
            this.translationLabel.Size = new System.Drawing.Size(245, 45);
            this.translationLabel.TabIndex = 1;
            this.translationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sinisterButton
            // 
            this.sinisterButton.Location = new System.Drawing.Point(82, 200);
            this.sinisterButton.Name = "sinisterButton";
            this.sinisterButton.Size = new System.Drawing.Size(99, 37);
            this.sinisterButton.TabIndex = 2;
            this.sinisterButton.Text = "Sinister";
            this.sinisterButton.UseVisualStyleBackColor = true;
            this.sinisterButton.Click += new System.EventHandler(this.sinisterButton_Click);
            // 
            // dexterButton
            // 
            this.dexterButton.Location = new System.Drawing.Point(222, 200);
            this.dexterButton.Name = "dexterButton";
            this.dexterButton.Size = new System.Drawing.Size(93, 37);
            this.dexterButton.TabIndex = 3;
            this.dexterButton.Text = "Dexter";
            this.dexterButton.UseVisualStyleBackColor = true;
            this.dexterButton.Click += new System.EventHandler(this.dexterButton_Click);
            // 
            // mediumButton
            // 
            this.mediumButton.Location = new System.Drawing.Point(367, 200);
            this.mediumButton.Name = "mediumButton";
            this.mediumButton.Size = new System.Drawing.Size(89, 37);
            this.mediumButton.TabIndex = 4;
            this.mediumButton.Text = "Medium";
            this.mediumButton.UseVisualStyleBackColor = true;
            this.mediumButton.Click += new System.EventHandler(this.mediumButton_Click);
            // 
            // clickForEnglishLabel
            // 
            this.clickForEnglishLabel.AutoSize = true;
            this.clickForEnglishLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clickForEnglishLabel.Location = new System.Drawing.Point(107, 150);
            this.clickForEnglishLabel.Name = "clickForEnglishLabel";
            this.clickForEnglishLabel.Size = new System.Drawing.Size(349, 16);
            this.clickForEnglishLabel.TabIndex = 5;
            this.clickForEnglishLabel.Text = "Click the Latin words below to see their English translation:";
            // 
            // latinTranslatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 294);
            this.Controls.Add(this.clickForEnglishLabel);
            this.Controls.Add(this.mediumButton);
            this.Controls.Add(this.dexterButton);
            this.Controls.Add(this.sinisterButton);
            this.Controls.Add(this.translationLabel);
            this.Controls.Add(this.thisIsEnglishLabel);
            this.Name = "latinTranslatorForm";
            this.Text = "Latin Translator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label thisIsEnglishLabel;
        private System.Windows.Forms.Label translationLabel;
        private System.Windows.Forms.Button sinisterButton;
        private System.Windows.Forms.Button dexterButton;
        private System.Windows.Forms.Button mediumButton;
        private System.Windows.Forms.Label clickForEnglishLabel;
    }
}

