﻿/**
* 1/30/2018
* CSC 153
* Mallory Milstead
* This program allows the user to click on a certain card and see the name of the card in a label box.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class cardIdentifierform : Form
    {
        public cardIdentifierform()
        {
            InitializeComponent();
        }

        private void queenHeartspicBox_Click(object sender, EventArgs e)
        {
            showCardnameLabel.Text = "Queen of Hearts";
        }

        private void tenSpadespicBox_Click(object sender, EventArgs e)
        {
            showCardnameLabel.Text = "Ten of Spades";
        }

        private void twoDiamondspicBox_Click(object sender, EventArgs e)
        {
            showCardnameLabel.Text = "Two of Diamonds";
        }

        private void jokerPicbox_Click(object sender, EventArgs e)
        {
            showCardnameLabel.Text = "Joker!";
        }

        private void kingHeartspicBox_Click(object sender, EventArgs e)
        {
            showCardnameLabel.Text = "King of Hearts";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
