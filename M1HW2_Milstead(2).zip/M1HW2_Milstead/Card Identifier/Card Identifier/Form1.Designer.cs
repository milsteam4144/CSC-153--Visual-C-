﻿namespace Card_Identifier
{
    partial class cardIdentifierform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showCardnameLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.kingHeartspicBox = new System.Windows.Forms.PictureBox();
            this.jokerPicbox = new System.Windows.Forms.PictureBox();
            this.twoDiamondspicBox = new System.Windows.Forms.PictureBox();
            this.tenSpadespicBox = new System.Windows.Forms.PictureBox();
            this.queenHeartspicBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.kingHeartspicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerPicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoDiamondspicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenSpadespicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenHeartspicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // showCardnameLabel
            // 
            this.showCardnameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.showCardnameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showCardnameLabel.Location = new System.Drawing.Point(174, 218);
            this.showCardnameLabel.Name = "showCardnameLabel";
            this.showCardnameLabel.Size = new System.Drawing.Size(439, 46);
            this.showCardnameLabel.TabIndex = 5;
            this.showCardnameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(343, 288);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(92, 34);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // kingHeartspicBox
            // 
            this.kingHeartspicBox.Image = global::Card_Identifier.Properties.Resources.King_Hearts;
            this.kingHeartspicBox.Location = new System.Drawing.Point(636, 12);
            this.kingHeartspicBox.Name = "kingHeartspicBox";
            this.kingHeartspicBox.Size = new System.Drawing.Size(130, 178);
            this.kingHeartspicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kingHeartspicBox.TabIndex = 4;
            this.kingHeartspicBox.TabStop = false;
            this.kingHeartspicBox.Click += new System.EventHandler(this.kingHeartspicBox_Click);
            // 
            // jokerPicbox
            // 
            this.jokerPicbox.Image = global::Card_Identifier.Properties.Resources.Joker_Black;
            this.jokerPicbox.Location = new System.Drawing.Point(483, 12);
            this.jokerPicbox.Name = "jokerPicbox";
            this.jokerPicbox.Size = new System.Drawing.Size(130, 178);
            this.jokerPicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.jokerPicbox.TabIndex = 3;
            this.jokerPicbox.TabStop = false;
            this.jokerPicbox.Click += new System.EventHandler(this.jokerPicbox_Click);
            // 
            // twoDiamondspicBox
            // 
            this.twoDiamondspicBox.Image = global::Card_Identifier.Properties.Resources._2_Diamonds;
            this.twoDiamondspicBox.Location = new System.Drawing.Point(330, 12);
            this.twoDiamondspicBox.Name = "twoDiamondspicBox";
            this.twoDiamondspicBox.Size = new System.Drawing.Size(130, 178);
            this.twoDiamondspicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twoDiamondspicBox.TabIndex = 2;
            this.twoDiamondspicBox.TabStop = false;
            this.twoDiamondspicBox.Click += new System.EventHandler(this.twoDiamondspicBox_Click);
            // 
            // tenSpadespicBox
            // 
            this.tenSpadespicBox.Image = global::Card_Identifier.Properties.Resources._10_Spades;
            this.tenSpadespicBox.Location = new System.Drawing.Point(174, 12);
            this.tenSpadespicBox.Name = "tenSpadespicBox";
            this.tenSpadespicBox.Size = new System.Drawing.Size(130, 178);
            this.tenSpadespicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tenSpadespicBox.TabIndex = 1;
            this.tenSpadespicBox.TabStop = false;
            this.tenSpadespicBox.Click += new System.EventHandler(this.tenSpadespicBox_Click);
            // 
            // queenHeartspicBox
            // 
            this.queenHeartspicBox.Image = global::Card_Identifier.Properties.Resources.Queen_Hearts;
            this.queenHeartspicBox.Location = new System.Drawing.Point(22, 12);
            this.queenHeartspicBox.Name = "queenHeartspicBox";
            this.queenHeartspicBox.Size = new System.Drawing.Size(130, 178);
            this.queenHeartspicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenHeartspicBox.TabIndex = 0;
            this.queenHeartspicBox.TabStop = false;
            this.queenHeartspicBox.Click += new System.EventHandler(this.queenHeartspicBox_Click);
            // 
            // cardIdentifierform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 334);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showCardnameLabel);
            this.Controls.Add(this.kingHeartspicBox);
            this.Controls.Add(this.jokerPicbox);
            this.Controls.Add(this.twoDiamondspicBox);
            this.Controls.Add(this.tenSpadespicBox);
            this.Controls.Add(this.queenHeartspicBox);
            this.Name = "cardIdentifierform";
            this.Text = "Card Identifier";
           // this.Load += new System.EventHandler(this.cardIdentifierform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kingHeartspicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerPicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoDiamondspicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenSpadespicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenHeartspicBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox queenHeartspicBox;
        private System.Windows.Forms.PictureBox tenSpadespicBox;
        private System.Windows.Forms.PictureBox twoDiamondspicBox;
        private System.Windows.Forms.PictureBox jokerPicbox;
        private System.Windows.Forms.PictureBox kingHeartspicBox;
        private System.Windows.Forms.Label showCardnameLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

