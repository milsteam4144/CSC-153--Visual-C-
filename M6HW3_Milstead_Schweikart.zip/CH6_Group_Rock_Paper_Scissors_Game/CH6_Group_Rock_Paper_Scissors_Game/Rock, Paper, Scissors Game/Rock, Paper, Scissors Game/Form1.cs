﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 04/16/2018
* CSC 153
* Mallory Milstead
* Brian Schweikart
* Rock, Paper, Scissors Game
*/

namespace Rock__Paper__Scissors_Game
{
    public partial class Form1 : Form
    {
        int compChoice;

        public Form1()
        {
            InitializeComponent();
        }

        // Find and display the winner
        private void DispalyWinner()
        {
            // Rock Smashes Scissors.
            if((fateTextBox.Text == "Rock" && compFateTextBox.Text == "Scissors") 
                || 
                (fateTextBox.Text == "Scissors" && compFateTextBox.Text == "Rock"))
            {
                resultTextBox.Text = "Rock Wins";
            }

            // Scissors cuts Paper.
            else if ((fateTextBox.Text == "Scissors" && compFateTextBox.Text == "Paper")
                ||
                (fateTextBox.Text == "Paper" && compFateTextBox.Text == "Scissors"))
            {
                resultTextBox.Text = "Scissors Wins";
            }

            // Paper covers Rock.
            else if ((fateTextBox.Text == "Paper" && compFateTextBox.Text == "Rock")
                ||
                (fateTextBox.Text == "Rock" && compFateTextBox.Text == "Paper"))
            {
                resultTextBox.Text = "Paper Wins";
            }

            // Draw Game.
            else if (((fateTextBox.Text == "Paper" && compFateTextBox.Text == "Paper")
                ||
                (fateTextBox.Text == "Scissors" && compFateTextBox.Text == "Scissors"))
                ||
                ((fateTextBox.Text == "Rock" && compFateTextBox.Text == "Rock")))
                
            {
                resultTextBox.Text = "Draw";

                // Show Draw game as a warning.
                MessageBox.Show("Try your Fate once more");
            }
        }

        // Random number method for comp pick
        private void randomNoGenerator()
        {
            Random rand = new Random();

            compChoice = rand.Next(1, 4);
        }

        // User selects Rock and find Comp selection and display winner
        private void rockPictureBox_Click(object sender, EventArgs e)
        {
            // Show players choice
            fateTextBox.Text = "Rock";

            // Call random method for computers choice
            randomNoGenerator();

            // Check Computer choice and display
            switch (compChoice)
            {
                case 1:
                    compFateTextBox.Text = "Rock";
                    break;

                case 2:
                    compFateTextBox.Text = "Paper";
                    break;

                case 3:
                    compFateTextBox.Text = "Scissors";
                    break;
            }
            
            // Call winner display method
            DispalyWinner();
        }

        // User selects Paper and find Comp selection and display winner
        private void paperPictureBox_Click(object sender, EventArgs e)
        {
            // Show players choice
            fateTextBox.Text = "Paper";

            // Call random method for computers choice
            randomNoGenerator();

            // Check Computer choice and display
            switch (compChoice)
            {
                case 1:
                    compFateTextBox.Text = "Rock";
                    break;

                case 2:
                    compFateTextBox.Text = "Paper";
                    break;

                case 3:
                    compFateTextBox.Text = "Scissors";
                    break;
            }

            // Call winner display method
            DispalyWinner();
        }

        // User selects Scissor and find Comp selection and display winner
        private void scissorPictureBox_Click(object sender, EventArgs e)
        {
            // Show players choice
            fateTextBox.Text = "Scissors";

            // Call random method for computers choice
            randomNoGenerator();

            // Check Computer choice and display
            switch (compChoice)
            {
                case 1:
                    compFateTextBox.Text = "Rock";
                    break;

                case 2:
                    compFateTextBox.Text = "Paper";
                    break;

                case 3:
                    compFateTextBox.Text = "Scissors";
                    break;
            }

            // Call winner display method
            DispalyWinner();
        }

        // Clear the Text Boxes "Not needed but added for people that like a blank screen
        private void clearButton_Click(object sender, EventArgs e)
        {
            fateTextBox.Text = "";
            compFateTextBox.Text = "";
            resultTextBox.Text = "";
        }

        // Close the Form
        private void exitButton_Click(object sender, EventArgs e)
        {
           this.Close();
        }
    }
}
