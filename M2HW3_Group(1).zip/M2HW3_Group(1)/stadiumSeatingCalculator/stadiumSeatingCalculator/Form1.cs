﻿/*
* 12 Feb 2018
* CSC 153
* Mallory Milstead & Chris Lee
* Stadium Seating Revenue Calculator
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stadiumSeatingCalculator
{
    public partial class stadiumSeatingForm : Form
    {
        public stadiumSeatingForm()
        {
            InitializeComponent();
        }
        //Initialize constant variables to proper values
        const int CLASS_A_COST = 15;
        const int CLASS_B_COST = 12;
        const int CLASS_C_COST = 9;

        //Initialize all integer variables to 0
        int classAsold = 0;
        int classBsold = 0;
        int classCsold = 0;
        int classAtot = 0;
        int classBtot = 0;
        int classCtot = 0;
        int totRevenue = 0;

        private void calcRevButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Test for proper input in TextBoxes 
                classAsold = int.Parse(ticketsSoldATextBox.Text);
                classBsold = int.Parse(ticketsSoldBTextBox.Text);
                classCsold = int.Parse(ticketsSoldCTextBox.Text);

                //Calculate revenue totals
                classAtot = classAsold * CLASS_A_COST;
                classBtot = classBsold * CLASS_B_COST;
                classCtot = classCsold * CLASS_C_COST;
                totRevenue = classAtot + classBtot + classCtot;

                //Print totals to proper label controls
                revenueGenATotLabel.Text = classAtot.ToString("C");
                revenueGenBTotLabel.Text = classBtot.ToString("C");
                revenueGenCTotLabel.Text = classCtot.ToString("C");
                revenueGenTotLabel.Text = totRevenue.ToString("C");

                //Disable TextBox controls to prevent accidental input
                ticketsSoldATextBox.Enabled = false;
                ticketsSoldBTextBox.Enabled = false;
                ticketsSoldCTextBox.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Enable TextBox controls
            ticketsSoldATextBox.Enabled = true;
            ticketsSoldBTextBox.Enabled = true;
            ticketsSoldCTextBox.Enabled = true;

            //Reset "Sold" variable values to 0
            classAsold = 0;
            classBsold = 0;
            classCsold = 0;

            //Return all text controls to null
            ticketsSoldATextBox.Text = "0";
            ticketsSoldBTextBox.Text = "0";
            ticketsSoldCTextBox.Text = "0";
            revenueGenATotLabel.Text = "";
            revenueGenBTotLabel.Text = "";
            revenueGenCTotLabel.Text = "";
            revenueGenTotLabel.Text = "";

            //Return focus to first textbox
            ticketsSoldATextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void stadiumSeatingForm_Load(object sender, EventArgs e)
        {
            //Set TextBox controls to 0
            ticketsSoldATextBox.Text = "0";
            ticketsSoldBTextBox.Text = "0";
            ticketsSoldCTextBox.Text = "0";
        }
    }
}
