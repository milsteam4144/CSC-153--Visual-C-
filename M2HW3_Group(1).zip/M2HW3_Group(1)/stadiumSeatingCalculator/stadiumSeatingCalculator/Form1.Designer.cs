﻿namespace stadiumSeatingCalculator
{
    partial class stadiumSeatingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ticketsSoldGroupBox = new System.Windows.Forms.GroupBox();
            this.ticketsSoldCTextBox = new System.Windows.Forms.TextBox();
            this.ticketsSoldBTextBox = new System.Windows.Forms.TextBox();
            this.ticketsSoldATextBox = new System.Windows.Forms.TextBox();
            this.ticketsSoldCLabel = new System.Windows.Forms.Label();
            this.ticketsSoldBLabel = new System.Windows.Forms.Label();
            this.ticketsSoldALabel = new System.Windows.Forms.Label();
            this.ticketsSoldInstructionLabel = new System.Windows.Forms.Label();
            this.revenueGenGroupBox = new System.Windows.Forms.GroupBox();
            this.revenueGenTotLabel = new System.Windows.Forms.Label();
            this.revenueGenCTotLabel = new System.Windows.Forms.Label();
            this.revenueGenATotLabel = new System.Windows.Forms.Label();
            this.revenueGenBTotLabel = new System.Windows.Forms.Label();
            this.revenueGenTotInfoLabel = new System.Windows.Forms.Label();
            this.revenueGenCLabel = new System.Windows.Forms.Label();
            this.revenueGenBLabel = new System.Windows.Forms.Label();
            this.revenueGenALabel = new System.Windows.Forms.Label();
            this.calcRevButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.ticketsSoldGroupBox.SuspendLayout();
            this.revenueGenGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ticketsSoldGroupBox
            // 
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldCTextBox);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldBTextBox);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldATextBox);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldCLabel);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldBLabel);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldALabel);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketsSoldInstructionLabel);
            this.ticketsSoldGroupBox.Location = new System.Drawing.Point(33, 15);
            this.ticketsSoldGroupBox.Name = "ticketsSoldGroupBox";
            this.ticketsSoldGroupBox.Size = new System.Drawing.Size(177, 155);
            this.ticketsSoldGroupBox.TabIndex = 0;
            this.ticketsSoldGroupBox.TabStop = false;
            this.ticketsSoldGroupBox.Text = "Tickets Sold";
            // 
            // ticketsSoldCTextBox
            // 
            this.ticketsSoldCTextBox.Location = new System.Drawing.Point(55, 117);
            this.ticketsSoldCTextBox.MaxLength = 5;
            this.ticketsSoldCTextBox.Name = "ticketsSoldCTextBox";
            this.ticketsSoldCTextBox.Size = new System.Drawing.Size(100, 20);
            this.ticketsSoldCTextBox.TabIndex = 6;
            // 
            // ticketsSoldBTextBox
            // 
            this.ticketsSoldBTextBox.Location = new System.Drawing.Point(55, 90);
            this.ticketsSoldBTextBox.MaxLength = 5;
            this.ticketsSoldBTextBox.Name = "ticketsSoldBTextBox";
            this.ticketsSoldBTextBox.Size = new System.Drawing.Size(100, 20);
            this.ticketsSoldBTextBox.TabIndex = 5;
            // 
            // ticketsSoldATextBox
            // 
            this.ticketsSoldATextBox.BackColor = System.Drawing.SystemColors.Window;
            this.ticketsSoldATextBox.Location = new System.Drawing.Point(55, 63);
            this.ticketsSoldATextBox.MaxLength = 5;
            this.ticketsSoldATextBox.Name = "ticketsSoldATextBox";
            this.ticketsSoldATextBox.Size = new System.Drawing.Size(100, 20);
            this.ticketsSoldATextBox.TabIndex = 4;
            // 
            // ticketsSoldCLabel
            // 
            this.ticketsSoldCLabel.AutoSize = true;
            this.ticketsSoldCLabel.Location = new System.Drawing.Point(8, 120);
            this.ticketsSoldCLabel.Name = "ticketsSoldCLabel";
            this.ticketsSoldCLabel.Size = new System.Drawing.Size(45, 13);
            this.ticketsSoldCLabel.TabIndex = 3;
            this.ticketsSoldCLabel.Text = "Class C:";
            // 
            // ticketsSoldBLabel
            // 
            this.ticketsSoldBLabel.AutoSize = true;
            this.ticketsSoldBLabel.Location = new System.Drawing.Point(8, 93);
            this.ticketsSoldBLabel.Name = "ticketsSoldBLabel";
            this.ticketsSoldBLabel.Size = new System.Drawing.Size(45, 13);
            this.ticketsSoldBLabel.TabIndex = 2;
            this.ticketsSoldBLabel.Text = "Class B:";
            // 
            // ticketsSoldALabel
            // 
            this.ticketsSoldALabel.AutoSize = true;
            this.ticketsSoldALabel.Location = new System.Drawing.Point(8, 66);
            this.ticketsSoldALabel.Name = "ticketsSoldALabel";
            this.ticketsSoldALabel.Size = new System.Drawing.Size(45, 13);
            this.ticketsSoldALabel.TabIndex = 1;
            this.ticketsSoldALabel.Text = "Class A:";
            // 
            // ticketsSoldInstructionLabel
            // 
            this.ticketsSoldInstructionLabel.Location = new System.Drawing.Point(6, 23);
            this.ticketsSoldInstructionLabel.Name = "ticketsSoldInstructionLabel";
            this.ticketsSoldInstructionLabel.Size = new System.Drawing.Size(170, 33);
            this.ticketsSoldInstructionLabel.TabIndex = 0;
            this.ticketsSoldInstructionLabel.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // revenueGenGroupBox
            // 
            this.revenueGenGroupBox.Controls.Add(this.revenueGenTotLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenCTotLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenATotLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenBTotLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenTotInfoLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenCLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenBLabel);
            this.revenueGenGroupBox.Controls.Add(this.revenueGenALabel);
            this.revenueGenGroupBox.Location = new System.Drawing.Point(225, 15);
            this.revenueGenGroupBox.Name = "revenueGenGroupBox";
            this.revenueGenGroupBox.Size = new System.Drawing.Size(164, 155);
            this.revenueGenGroupBox.TabIndex = 1;
            this.revenueGenGroupBox.TabStop = false;
            this.revenueGenGroupBox.Text = "Revenue Generated";
            // 
            // revenueGenTotLabel
            // 
            this.revenueGenTotLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.revenueGenTotLabel.Location = new System.Drawing.Point(56, 117);
            this.revenueGenTotLabel.Name = "revenueGenTotLabel";
            this.revenueGenTotLabel.Size = new System.Drawing.Size(94, 24);
            this.revenueGenTotLabel.TabIndex = 7;
            this.revenueGenTotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // revenueGenCTotLabel
            // 
            this.revenueGenCTotLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.revenueGenCTotLabel.Location = new System.Drawing.Point(56, 88);
            this.revenueGenCTotLabel.Name = "revenueGenCTotLabel";
            this.revenueGenCTotLabel.Size = new System.Drawing.Size(94, 24);
            this.revenueGenCTotLabel.TabIndex = 6;
            this.revenueGenCTotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // revenueGenATotLabel
            // 
            this.revenueGenATotLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.revenueGenATotLabel.Location = new System.Drawing.Point(56, 30);
            this.revenueGenATotLabel.Name = "revenueGenATotLabel";
            this.revenueGenATotLabel.Size = new System.Drawing.Size(94, 24);
            this.revenueGenATotLabel.TabIndex = 5;
            this.revenueGenATotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // revenueGenBTotLabel
            // 
            this.revenueGenBTotLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.revenueGenBTotLabel.Location = new System.Drawing.Point(56, 59);
            this.revenueGenBTotLabel.Name = "revenueGenBTotLabel";
            this.revenueGenBTotLabel.Size = new System.Drawing.Size(94, 24);
            this.revenueGenBTotLabel.TabIndex = 4;
            this.revenueGenBTotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // revenueGenTotInfoLabel
            // 
            this.revenueGenTotInfoLabel.AutoSize = true;
            this.revenueGenTotInfoLabel.Location = new System.Drawing.Point(19, 122);
            this.revenueGenTotInfoLabel.Name = "revenueGenTotInfoLabel";
            this.revenueGenTotInfoLabel.Size = new System.Drawing.Size(34, 13);
            this.revenueGenTotInfoLabel.TabIndex = 3;
            this.revenueGenTotInfoLabel.Text = "Total:";
            // 
            // revenueGenCLabel
            // 
            this.revenueGenCLabel.AutoSize = true;
            this.revenueGenCLabel.Location = new System.Drawing.Point(8, 93);
            this.revenueGenCLabel.Name = "revenueGenCLabel";
            this.revenueGenCLabel.Size = new System.Drawing.Size(45, 13);
            this.revenueGenCLabel.TabIndex = 2;
            this.revenueGenCLabel.Text = "Class C:";
            // 
            // revenueGenBLabel
            // 
            this.revenueGenBLabel.AutoSize = true;
            this.revenueGenBLabel.Location = new System.Drawing.Point(8, 64);
            this.revenueGenBLabel.Name = "revenueGenBLabel";
            this.revenueGenBLabel.Size = new System.Drawing.Size(45, 13);
            this.revenueGenBLabel.TabIndex = 1;
            this.revenueGenBLabel.Text = "Class B:";
            // 
            // revenueGenALabel
            // 
            this.revenueGenALabel.AutoSize = true;
            this.revenueGenALabel.Location = new System.Drawing.Point(8, 34);
            this.revenueGenALabel.Name = "revenueGenALabel";
            this.revenueGenALabel.Size = new System.Drawing.Size(45, 13);
            this.revenueGenALabel.TabIndex = 0;
            this.revenueGenALabel.Text = "Class A:";
            // 
            // calcRevButton
            // 
            this.calcRevButton.Location = new System.Drawing.Point(88, 183);
            this.calcRevButton.Name = "calcRevButton";
            this.calcRevButton.Size = new System.Drawing.Size(77, 40);
            this.calcRevButton.TabIndex = 2;
            this.calcRevButton.Text = "Calculate Revenue";
            this.calcRevButton.UseVisualStyleBackColor = true;
            this.calcRevButton.Click += new System.EventHandler(this.calcRevButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(179, 183);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(77, 40);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(271, 183);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(77, 40);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // stadiumSeatingForm
            // 
            this.AcceptButton = this.calcRevButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 238);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcRevButton);
            this.Controls.Add(this.revenueGenGroupBox);
            this.Controls.Add(this.ticketsSoldGroupBox);
            this.Name = "stadiumSeatingForm";
            this.Text = "Stadium Seating";
            this.Load += new System.EventHandler(this.stadiumSeatingForm_Load);
            this.ticketsSoldGroupBox.ResumeLayout(false);
            this.ticketsSoldGroupBox.PerformLayout();
            this.revenueGenGroupBox.ResumeLayout(false);
            this.revenueGenGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ticketsSoldGroupBox;
        private System.Windows.Forms.TextBox ticketsSoldCTextBox;
        private System.Windows.Forms.TextBox ticketsSoldBTextBox;
        private System.Windows.Forms.TextBox ticketsSoldATextBox;
        private System.Windows.Forms.Label ticketsSoldCLabel;
        private System.Windows.Forms.Label ticketsSoldBLabel;
        private System.Windows.Forms.Label ticketsSoldALabel;
        private System.Windows.Forms.Label ticketsSoldInstructionLabel;
        private System.Windows.Forms.GroupBox revenueGenGroupBox;
        private System.Windows.Forms.Label revenueGenTotLabel;
        private System.Windows.Forms.Label revenueGenCTotLabel;
        private System.Windows.Forms.Label revenueGenATotLabel;
        private System.Windows.Forms.Label revenueGenBTotLabel;
        private System.Windows.Forms.Label revenueGenTotInfoLabel;
        private System.Windows.Forms.Label revenueGenCLabel;
        private System.Windows.Forms.Label revenueGenBLabel;
        private System.Windows.Forms.Label revenueGenALabel;
        private System.Windows.Forms.Button calcRevButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

