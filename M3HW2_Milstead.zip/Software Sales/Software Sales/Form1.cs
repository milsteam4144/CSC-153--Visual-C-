﻿/**
* 2/27/2018
* CSC 153
* Mallory Milstead
* This program prompts user to enter a quantity of items and then calculates a discount and total based on the quantity of items ordered.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class softwareSalesForm : Form
    {

        //Field variable to hold the discount.
        private decimal discount = 0m;


        public softwareSalesForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

            //Initialize variable for quantity.
            int quantity;


            //If user input to the quantity text box is an int, output that value to quantity.
            if (int.TryParse(quantityTextBox.Text, out quantity))
            {


                /*The following if-else block :
                 * If quantity is within the threshold, assign the appropriate discount and output that discount amount to a label.**/

                if (quantity >= 10 && quantity <= 19)
                {
                    discount = .20m;
                    percentDiscountLabel.Text = ("20%");
                }

                else if (quantity >= 20 && quantity <= 49)
                {
                    discount = .30m;
                    percentDiscountLabel.Text = ("30%");
                }

                else if (quantity >= 50 && quantity <= 99)
                {
                    discount = .40m;
                    percentDiscountLabel.Text = ("40%");
                }

                else if (quantity >= 100)
                {
                    discount = .50m;
                    percentDiscountLabel.Text = ("50%");
                }

                else
                {
                    discount = 0m;
                    percentDiscountLabel.Text = ("None");
                }

            }

            //If quantity cannot be parsed into an int, display the following messagebox:
            else
            {
                MessageBox.Show("Please enter a valid whole number.");
            }


            //Initialize variable for the cost of each item.
            decimal individualCost = 99.0m;
           
            //Initialize variable and calculate cost of order without any discounts.
            decimal noDisc_price = quantity * individualCost;

            //Display the order total before any discounts.
            noDiscOutputLabel.Text = noDisc_price.ToString("c");

            //Initialize and calculate dollar amount of discount.
            decimal dollar_discount = noDisc_price * discount;

            //Calculate the cost of the order with discount.
            decimal Disc_price = noDisc_price - dollar_discount;

            //Display amount of discount.
            discountOutputLabel.Text = dollar_discount.ToString("c");

            //Display the total price of the order WITH discount.
            totalOutputLabel.Text = Disc_price.ToString("c");






        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the form by clearing all labels.
            quantityTextBox.Text = "";
            discountOutputLabel.Text = "";
            totalOutputLabel.Text = "";
            noDiscOutputLabel.Text = "";
            percentDiscountLabel.Text = "";

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
