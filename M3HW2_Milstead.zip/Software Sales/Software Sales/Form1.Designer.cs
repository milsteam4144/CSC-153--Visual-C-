﻿namespace Software_Sales
{
    partial class softwareSalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterQuantityLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.discountAmountLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.discountOutputLabel = new System.Windows.Forms.Label();
            this.totalOutputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.discountPercentLabel = new System.Windows.Forms.Label();
            this.percentDiscountLabel = new System.Windows.Forms.Label();
            this.withoutLabel = new System.Windows.Forms.Label();
            this.noDiscOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // enterQuantityLabel
            // 
            this.enterQuantityLabel.AutoSize = true;
            this.enterQuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterQuantityLabel.Location = new System.Drawing.Point(15, 56);
            this.enterQuantityLabel.Name = "enterQuantityLabel";
            this.enterQuantityLabel.Size = new System.Drawing.Size(104, 15);
            this.enterQuantityLabel.TabIndex = 0;
            this.enterQuantityLabel.Text = "Enter the quantity:";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(15, 21);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(495, 16);
            this.descriptionLabel.TabIndex = 2;
            this.descriptionLabel.Text = "Enter the quantity of packages below to determine the amount of discount and tota" +
    "l.";
            // 
            // discountAmountLabel
            // 
            this.discountAmountLabel.AutoSize = true;
            this.discountAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discountAmountLabel.Location = new System.Drawing.Point(283, 111);
            this.discountAmountLabel.Name = "discountAmountLabel";
            this.discountAmountLabel.Size = new System.Drawing.Size(18, 15);
            this.discountAmountLabel.TabIndex = 3;
            this.discountAmountLabel.Text = "or";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(71, 174);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(123, 18);
            this.totalLabel.TabIndex = 4;
            this.totalLabel.Text = "The order total is:";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(137, 56);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 20);
            this.quantityTextBox.TabIndex = 5;
            // 
            // discountOutputLabel
            // 
            this.discountOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discountOutputLabel.ForeColor = System.Drawing.Color.Maroon;
            this.discountOutputLabel.Location = new System.Drawing.Point(317, 102);
            this.discountOutputLabel.Name = "discountOutputLabel";
            this.discountOutputLabel.Size = new System.Drawing.Size(121, 24);
            this.discountOutputLabel.TabIndex = 6;
            this.discountOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalOutputLabel
            // 
            this.totalOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalOutputLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.totalOutputLabel.Location = new System.Drawing.Point(209, 171);
            this.totalOutputLabel.Name = "totalOutputLabel";
            this.totalOutputLabel.Size = new System.Drawing.Size(142, 25);
            this.totalOutputLabel.TabIndex = 7;
            this.totalOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(40, 224);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(107, 50);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(194, 224);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(107, 50);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(358, 224);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(107, 50);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // discountPercentLabel
            // 
            this.discountPercentLabel.AutoSize = true;
            this.discountPercentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discountPercentLabel.Location = new System.Drawing.Point(37, 107);
            this.discountPercentLabel.Name = "discountPercentLabel";
            this.discountPercentLabel.Size = new System.Drawing.Size(157, 15);
            this.discountPercentLabel.TabIndex = 11;
            this.discountPercentLabel.Text = "The discount percentage is:";
            // 
            // percentDiscountLabel
            // 
            this.percentDiscountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.percentDiscountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentDiscountLabel.ForeColor = System.Drawing.Color.Maroon;
            this.percentDiscountLabel.Location = new System.Drawing.Point(209, 102);
            this.percentDiscountLabel.Name = "percentDiscountLabel";
            this.percentDiscountLabel.Size = new System.Drawing.Size(55, 24);
            this.percentDiscountLabel.TabIndex = 12;
            this.percentDiscountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // withoutLabel
            // 
            this.withoutLabel.AutoSize = true;
            this.withoutLabel.Location = new System.Drawing.Point(269, 58);
            this.withoutLabel.Name = "withoutLabel";
            this.withoutLabel.Size = new System.Drawing.Size(112, 13);
            this.withoutLabel.TabIndex = 13;
            this.withoutLabel.Text = "Total before Discount:";
            // 
            // noDiscOutputLabel
            // 
            this.noDiscOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.noDiscOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noDiscOutputLabel.Location = new System.Drawing.Point(387, 52);
            this.noDiscOutputLabel.Name = "noDiscOutputLabel";
            this.noDiscOutputLabel.Size = new System.Drawing.Size(123, 24);
            this.noDiscOutputLabel.TabIndex = 14;
            this.noDiscOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // softwareSalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 301);
            this.Controls.Add(this.noDiscOutputLabel);
            this.Controls.Add(this.withoutLabel);
            this.Controls.Add(this.percentDiscountLabel);
            this.Controls.Add(this.discountPercentLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalOutputLabel);
            this.Controls.Add(this.discountOutputLabel);
            this.Controls.Add(this.quantityTextBox);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.discountAmountLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.enterQuantityLabel);
            this.Name = "softwareSalesForm";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterQuantityLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label discountAmountLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.Label discountOutputLabel;
        private System.Windows.Forms.Label totalOutputLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label discountPercentLabel;
        private System.Windows.Forms.Label percentDiscountLabel;
        private System.Windows.Forms.Label withoutLabel;
        private System.Windows.Forms.Label noDiscOutputLabel;
    }
}

