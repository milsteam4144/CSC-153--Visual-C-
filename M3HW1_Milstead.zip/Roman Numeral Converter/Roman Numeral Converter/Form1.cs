﻿/**
* 2/22/2018
* CSC 153
* Mallory Milstead
* This program converts a number (1-10) that user inputs into a roman numeral. If the user enters a non-integer or number outside of range, a messagebox displays the error.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class romanConverterForm : Form
    { 

        public romanConverterForm()
        {
            InitializeComponent();
        }

        private void displayRomanButton_Click(object sender, EventArgs e)
        {

            //Initiate variable to hold user input.
            int reg_num;

            //If the user input can be parsed into an integer, the switch statement executes.
            if (int.TryParse(inputTextBox.Text, out reg_num))


            {
                //Switch statement returns a specific output depending on the value of reg_num.
                switch (reg_num)
                {
                    case 1:
                        displayRomanLabel.Text = ("I");
                        break;
                    case 2:
                        displayRomanLabel.Text = ("II");
                        break;
                    case 3:
                        displayRomanLabel.Text = ("III");
                        break;
                    case 4:
                        displayRomanLabel.Text = ("IV");
                        break;
                    case 5:
                        displayRomanLabel.Text = ("V");
                        break;
                    case 6:
                        displayRomanLabel.Text = ("VI");
                        break;
                    case 7:
                        displayRomanLabel.Text = ("VII");
                        break;
                    case 8:
                        displayRomanLabel.Text = ("VIII");
                        break;
                    case 9:
                        displayRomanLabel.Text = ("IX");
                        break;
                    case 10:
                        displayRomanLabel.Text = ("X");
                        break;

                    //If none of the above cases are true, the default block executes.
                    default:
                        MessageBox.Show("The number you entered is not between 1 and 10");
                        break;
                }
            }


                else
                {
                //If the "if" statement is not true, the else block executes.
                MessageBox.Show("You did not enter a number.");
                }

            }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the form by clearing the textbox and display label.
            inputTextBox.Text = ("");
            displayRomanLabel.Text = ("");
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    } } 
