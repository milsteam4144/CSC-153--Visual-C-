﻿namespace Roman_Numeral_Converter
{
    partial class romanConverterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.explainLabel = new System.Windows.Forms.Label();
            this.inputLabel = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.displayRomanLabel = new System.Windows.Forms.Label();
            this.displayRomanButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // explainLabel
            // 
            this.explainLabel.AutoSize = true;
            this.explainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.explainLabel.Location = new System.Drawing.Point(35, 33);
            this.explainLabel.Name = "explainLabel";
            this.explainLabel.Size = new System.Drawing.Size(387, 16);
            this.explainLabel.TabIndex = 0;
            this.explainLabel.Text = "This program will convert a number (1-10) into a Roman numeral.";
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputLabel.Location = new System.Drawing.Point(25, 118);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(151, 15);
            this.inputLabel.TabIndex = 1;
            this.inputLabel.Text = "Enter a number from 1-10:";
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(25, 184);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(136, 15);
            this.displayLabel.TabIndex = 2;
            this.displayLabel.Text = "The Roman numeral is:";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputTextBox.Location = new System.Drawing.Point(182, 113);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(114, 21);
            this.inputTextBox.TabIndex = 3;
            // 
            // displayRomanLabel
            // 
            this.displayRomanLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayRomanLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayRomanLabel.Location = new System.Drawing.Point(181, 183);
            this.displayRomanLabel.Name = "displayRomanLabel";
            this.displayRomanLabel.Size = new System.Drawing.Size(115, 26);
            this.displayRomanLabel.TabIndex = 4;
            this.displayRomanLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayRomanButton
            // 
            this.displayRomanButton.Location = new System.Drawing.Point(38, 265);
            this.displayRomanButton.Name = "displayRomanButton";
            this.displayRomanButton.Size = new System.Drawing.Size(102, 68);
            this.displayRomanButton.TabIndex = 5;
            this.displayRomanButton.Text = "Display Roman Numeral";
            this.displayRomanButton.UseVisualStyleBackColor = true;
            this.displayRomanButton.Click += new System.EventHandler(this.displayRomanButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(170, 265);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(102, 68);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(299, 265);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(102, 68);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // romanConverterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 365);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayRomanButton);
            this.Controls.Add(this.displayRomanLabel);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.explainLabel);
            this.Name = "romanConverterForm";
            this.Text = "Roman Numeral Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label explainLabel;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Label displayRomanLabel;
        private System.Windows.Forms.Button displayRomanButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

