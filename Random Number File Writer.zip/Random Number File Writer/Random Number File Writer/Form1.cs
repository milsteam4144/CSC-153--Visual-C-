﻿/**
* 3/20/2018
* CSC 153
* Milstead, Miller, Kleiner
* This program creates a file and writes a specified number of random integers to the file.
* It allows the user to give the file a unique name and save it in a location of their choosing.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Writer
{
    public partial class randomWriter_Form : Form
    {
        public randomWriter_Form()
        {
            InitializeComponent();
        }

        private void save_Button_Click(object sender, EventArgs e)
        {
            //Initialize variables.
             int numOfnums, count, ranNum;
            
            //Create an object for the output file.
            StreamWriter outputFile;

            //If the user input can be parsed into an int, continue.
            if (int.TryParse(input_TextBox.Text, out numOfnums))
            {
                //If the user saves the file, continue.
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    //Create the file.
                    outputFile = File.CreateText(saveFile.FileName + ".txt");

                    //Create a Random Object.
                    Random rand = new Random();
                       
                    //For loop iterates a specific number of times according to user input.
                        for (count = 1; count <= numOfnums; count += 1)
                        {
                            //Get a random integer and assign it to a variable.
                            ranNum = rand.Next(100) + 1;

                            //Write the random numbers to the file.
                            outputFile.WriteLine(ranNum);
                        }

                        //Close the file.
                        outputFile.Close();

                        //Show messagebox that file was saved.
                        MessageBox.Show("File saved successfully.");

                    //Clear the textbox.
                    input_TextBox.Text = "";
                }
                else
                {
                    //If user does not save file, show messagebox.
                    MessageBox.Show("File not saved");
                }
            }
            else
            {   //If user input cannot be parsed to an int, show messagebox.
                MessageBox.Show("Invalid data entered.");
            }
        }

        private void exit_Button_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
