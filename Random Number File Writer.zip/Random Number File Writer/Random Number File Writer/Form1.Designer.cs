﻿namespace Random_Number_File_Writer
{
    partial class randomWriter_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.input_Label = new System.Windows.Forms.Label();
            this.input_TextBox = new System.Windows.Forms.TextBox();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.save_Button = new System.Windows.Forms.Button();
            this.exit_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // input_Label
            // 
            this.input_Label.AutoSize = true;
            this.input_Label.Location = new System.Drawing.Point(12, 43);
            this.input_Label.Name = "input_Label";
            this.input_Label.Size = new System.Drawing.Size(241, 13);
            this.input_Label.TabIndex = 0;
            this.input_Label.Text = "Enter the amount of random numbers to generate:";
            // 
            // input_TextBox
            // 
            this.input_TextBox.Location = new System.Drawing.Point(259, 40);
            this.input_TextBox.Name = "input_TextBox";
            this.input_TextBox.Size = new System.Drawing.Size(100, 20);
            this.input_TextBox.TabIndex = 1;
            // 
            // save_Button
            // 
            this.save_Button.Location = new System.Drawing.Point(65, 113);
            this.save_Button.Name = "save_Button";
            this.save_Button.Size = new System.Drawing.Size(99, 55);
            this.save_Button.TabIndex = 2;
            this.save_Button.Text = "Save File";
            this.save_Button.UseVisualStyleBackColor = true;
            this.save_Button.Click += new System.EventHandler(this.save_Button_Click);
            // 
            // exit_Button
            // 
            this.exit_Button.Location = new System.Drawing.Point(204, 113);
            this.exit_Button.Name = "exit_Button";
            this.exit_Button.Size = new System.Drawing.Size(99, 55);
            this.exit_Button.TabIndex = 3;
            this.exit_Button.Text = "Exit";
            this.exit_Button.UseVisualStyleBackColor = true;
            this.exit_Button.Click += new System.EventHandler(this.exit_Button_Click);
            // 
            // randomWriter_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 189);
            this.Controls.Add(this.exit_Button);
            this.Controls.Add(this.save_Button);
            this.Controls.Add(this.input_TextBox);
            this.Controls.Add(this.input_Label);
            this.Name = "randomWriter_Form";
            this.Text = "Random Number File Writer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label input_Label;
        private System.Windows.Forms.TextBox input_TextBox;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.Button save_Button;
        private System.Windows.Forms.Button exit_Button;
    }
}

