﻿/**
* 3/25/2018
* CSC 153
* Mallory Milstead
* This program accepts user input, calculates population using a "for loop" and displays the results in a listbox.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class populationForm : Form
    {
        public populationForm()
        {
            InitializeComponent();
        }

        private void calculate_button_Click(object sender, EventArgs e)
        {
            //Declare variables
            double startNum, perInc, numDays, count, increase;

            //If data in textbox can be parsed assign that value to the variable.
            if (double.TryParse(start_num_textbox.Text, out startNum))
            {

                if (double.TryParse(increase_textbox.Text, out perInc))
                {

                    if (double.TryParse(days_textbox.Text, out numDays))
                    {

                        display_listbox.Items.Add("Day" + "     " + "Approximate Population");
                        //Create a for loop to calculate the population.
                        for (count = 1; count <= numDays; count += 1)
                        {
                            //string displayNum = String.Format("{0,8}", startNum.ToString());

                            display_listbox.Items.Add(" " + count + "\t \t" + startNum);
                            increase = (perInc / 100) * startNum;
                            startNum = startNum + increase ;
                            
                        }
                    }

                    else
                    {
                        MessageBox.Show("Invalid number of days entered.");
                    }
                }

                else
                {
                    MessageBox.Show("Invalid percentage of increase entered.");
                }
            }

            else
            {
                MessageBox.Show("Invalid starting number entered.");
            }

               
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
