﻿namespace WindowsFormsApp1
{
    partial class populationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.start_num_textbox = new System.Windows.Forms.TextBox();
            this.increase_textbox = new System.Windows.Forms.TextBox();
            this.days_textbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.display_listbox = new System.Windows.Forms.ListBox();
            this.calculate_button = new System.Windows.Forms.Button();
            this.clear_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // start_num_textbox
            // 
            this.start_num_textbox.Location = new System.Drawing.Point(259, 23);
            this.start_num_textbox.Name = "start_num_textbox";
            this.start_num_textbox.Size = new System.Drawing.Size(100, 20);
            this.start_num_textbox.TabIndex = 0;
            // 
            // increase_textbox
            // 
            this.increase_textbox.Location = new System.Drawing.Point(259, 57);
            this.increase_textbox.Name = "increase_textbox";
            this.increase_textbox.Size = new System.Drawing.Size(100, 20);
            this.increase_textbox.TabIndex = 1;
            // 
            // days_textbox
            // 
            this.days_textbox.Location = new System.Drawing.Point(259, 83);
            this.days_textbox.Name = "days_textbox";
            this.days_textbox.Size = new System.Drawing.Size(100, 20);
            this.days_textbox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter starting number of organisms:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter the average daily increase (percentage):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter the number of days to multiply:";
            // 
            // display_listbox
            // 
            this.display_listbox.FormattingEnabled = true;
            this.display_listbox.Location = new System.Drawing.Point(104, 133);
            this.display_listbox.Name = "display_listbox";
            this.display_listbox.Size = new System.Drawing.Size(207, 199);
            this.display_listbox.TabIndex = 6;
            // 
            // calculate_button
            // 
            this.calculate_button.Location = new System.Drawing.Point(41, 372);
            this.calculate_button.Name = "calculate_button";
            this.calculate_button.Size = new System.Drawing.Size(91, 59);
            this.calculate_button.TabIndex = 7;
            this.calculate_button.Text = "Calculate Population";
            this.calculate_button.UseVisualStyleBackColor = true;
            this.calculate_button.Click += new System.EventHandler(this.calculate_button_Click);
            // 
            // clear_button
            // 
            this.clear_button.Location = new System.Drawing.Point(153, 372);
            this.clear_button.Name = "clear_button";
            this.clear_button.Size = new System.Drawing.Size(89, 59);
            this.clear_button.TabIndex = 8;
            this.clear_button.Text = "Clear Form";
            this.clear_button.UseVisualStyleBackColor = true;
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(259, 372);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(105, 59);
            this.exit_button.TabIndex = 9;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // populationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 458);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.clear_button);
            this.Controls.Add(this.calculate_button);
            this.Controls.Add(this.display_listbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.days_textbox);
            this.Controls.Add(this.increase_textbox);
            this.Controls.Add(this.start_num_textbox);
            this.Name = "populationForm";
            this.Text = "Population Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox start_num_textbox;
        private System.Windows.Forms.TextBox increase_textbox;
        private System.Windows.Forms.TextBox days_textbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox display_listbox;
        private System.Windows.Forms.Button calculate_button;
        private System.Windows.Forms.Button clear_button;
        private System.Windows.Forms.Button exit_button;
    }
}

