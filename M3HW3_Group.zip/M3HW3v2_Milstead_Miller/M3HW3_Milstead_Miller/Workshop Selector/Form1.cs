﻿/**
* March 11, 2018
* CSC 153
* Jenica and Mallory
* This programs determines the amount of a workshop per location
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class Form1 : Form
    {
        //Declare private variables.
        private int days = 0, workshopFee = 0, location_fee = 0;

        public Form1()
        {
            InitializeComponent();
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close this form.
            this.Close();
        }
        private void resetButton_Click(object sender, EventArgs e)
        {
            //Clear choices
            totalLabel.Text = "";
            locListBox.SelectedItem = null;
            wsListBox.SelectedItem = null;
        }
        private void workshopButton_Click(object sender, EventArgs e)
        {
            //Declare variables.
            int total;
            string location = ""; string selected_ws = "";
            
            //Determine the location and location fees
            try
            {
                location = locListBox.SelectedItem.ToString();
                selected_ws = wsListBox.SelectedItem.ToString();
            }
            catch
            {
                MessageBox.Show("Pick a location and workshop.");
            }
                switch (location)

            {
                case "Austin": location_fee = 150; break;
                case "Chicago": location_fee = 225; break;
                case "Dallas": location_fee = 175; break;
                case "Orlando": location_fee = 300; break;
                case "Phoenix": location_fee = 175; break;
                case "Raleigh": location_fee = 150; break;
            }

            //Determine workshop length and fees   
            switch (selected_ws)
            {
                case "Handling Stress": workshopFee = 1000; days = 3; break;
                case "Time Management": workshopFee = 800; days = 3; break;
                case "Supervision Skills": workshopFee = 1500; days = 3; break;
                case "Negotiation": workshopFee = 1300; days = 5; break;
                case "How to Interview": workshopFee = 500; days = 1; break;
            }

            //Calculate the total cost of the workshop
            total = (days * location_fee) + workshopFee;
            totalLabel.Text = total.ToString("c");
        }
    }

}


