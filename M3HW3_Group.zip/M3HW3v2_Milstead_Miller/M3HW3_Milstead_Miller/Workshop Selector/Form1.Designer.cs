﻿namespace Workshop_Selector
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopGroupBox = new System.Windows.Forms.GroupBox();
            this.wsListBox = new System.Windows.Forms.ListBox();
            this.locationGroupBox = new System.Windows.Forms.GroupBox();
            this.locListBox = new System.Windows.Forms.ListBox();
            this.amountLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.workshopButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.workshopGroupBox.SuspendLayout();
            this.locationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // workshopGroupBox
            // 
            this.workshopGroupBox.Controls.Add(this.wsListBox);
            this.workshopGroupBox.Location = new System.Drawing.Point(26, 12);
            this.workshopGroupBox.Name = "workshopGroupBox";
            this.workshopGroupBox.Size = new System.Drawing.Size(200, 139);
            this.workshopGroupBox.TabIndex = 0;
            this.workshopGroupBox.TabStop = false;
            this.workshopGroupBox.Text = "Pick a Workshop:";
            // 
            // wsListBox
            // 
            this.wsListBox.FormattingEnabled = true;
            this.wsListBox.Items.AddRange(new object[] {
            "Handling Stress",
            "Time Management",
            "Supervision Skills",
            "Negotiation",
            "How to Interview"});
            this.wsListBox.Location = new System.Drawing.Point(32, 19);
            this.wsListBox.Name = "wsListBox";
            this.wsListBox.Size = new System.Drawing.Size(140, 108);
            this.wsListBox.TabIndex = 0;
//            this.wsListBox.SelectedIndexChanged += new System.EventHandler(this.wsListBox_SelectedIndexChanged);
            // 
            // locationGroupBox
            // 
            this.locationGroupBox.Controls.Add(this.locListBox);
            this.locationGroupBox.Location = new System.Drawing.Point(248, 12);
            this.locationGroupBox.Name = "locationGroupBox";
            this.locationGroupBox.Size = new System.Drawing.Size(200, 139);
            this.locationGroupBox.TabIndex = 1;
            this.locationGroupBox.TabStop = false;
            this.locationGroupBox.Text = "Pick a Location:";
            // 
            // locListBox
            // 
            this.locListBox.FormattingEnabled = true;
            this.locListBox.Items.AddRange(new object[] {
            "Austin",
            "Chicago",
            "Dallas",
            "Orlando",
            "Phoenix",
            "Raleigh"});
            this.locListBox.Location = new System.Drawing.Point(32, 19);
            this.locListBox.Name = "locListBox";
            this.locListBox.Size = new System.Drawing.Size(140, 108);
            this.locListBox.TabIndex = 0;
            //this.locListBox.SelectedIndexChanged += new System.EventHandler(this.locListBox_SelectedIndexChanged);
            // 
            // amountLabel
            // 
            this.amountLabel.AutoSize = true;
            this.amountLabel.Location = new System.Drawing.Point(128, 195);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(98, 13);
            this.amountLabel.TabIndex = 2;
            this.amountLabel.Text = "Total for workshop:";
            // 
            // totalLabel
            // 
            this.totalLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(243, 190);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 23);
            this.totalLabel.TabIndex = 3;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // workshopButton
            // 
            this.workshopButton.Location = new System.Drawing.Point(87, 264);
            this.workshopButton.Name = "workshopButton";
            this.workshopButton.Size = new System.Drawing.Size(75, 38);
            this.workshopButton.TabIndex = 4;
            this.workshopButton.Text = "Calcuate Total";
            this.workshopButton.UseVisualStyleBackColor = true;
            this.workshopButton.Click += new System.EventHandler(this.workshopButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(208, 264);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 38);
            this.resetButton.TabIndex = 5;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(328, 264);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 38);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 325);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.workshopButton);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.amountLabel);
            this.Controls.Add(this.locationGroupBox);
            this.Controls.Add(this.workshopGroupBox);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.workshopGroupBox.ResumeLayout(false);
            this.locationGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox workshopGroupBox;
        private System.Windows.Forms.ListBox wsListBox;
        private System.Windows.Forms.GroupBox locationGroupBox;
        private System.Windows.Forms.ListBox locListBox;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button workshopButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

