﻿namespace Name_Formatter
{
    partial class nameFormatterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.titleFirstMiddleLastButton = new System.Windows.Forms.Button();
            this.firstMiddleLastButton = new System.Windows.Forms.Button();
            this.firstLastButton = new System.Windows.Forms.Button();
            this.last_FirstMiddle_titleButton = new System.Windows.Forms.Button();
            this.last_FirstMiddleButton = new System.Windows.Forms.Button();
            this.last_FirstButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.chooseFormatLabel = new System.Windows.Forms.Label();
            this.yourNameLabel = new System.Windows.Forms.Label();
            this.nameOutputLabel = new System.Windows.Forms.Label();
            this.titleGroupBox = new System.Windows.Forms.GroupBox();
            this.drRadio = new System.Windows.Forms.RadioButton();
            this.mrRadio = new System.Windows.Forms.RadioButton();
            this.mrsRadio = new System.Windows.Forms.RadioButton();
            this.msRadio = new System.Windows.Forms.RadioButton();
            this.titleGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(75, 22);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(353, 20);
            this.descriptionLabel.TabIndex = 0;
            this.descriptionLabel.Text = "Please enter your full name and title below:";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLabel.Location = new System.Drawing.Point(76, 123);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(85, 18);
            this.firstNameLabel.TabIndex = 2;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameLabel.Location = new System.Drawing.Point(60, 166);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(99, 18);
            this.middleNameLabel.TabIndex = 3;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLabel.Location = new System.Drawing.Point(76, 204);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(84, 18);
            this.lastNameLabel.TabIndex = 4;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameTextBox.Location = new System.Drawing.Point(182, 123);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(120, 22);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameTextBox.Location = new System.Drawing.Point(182, 198);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(120, 22);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameTextBox.Location = new System.Drawing.Point(182, 160);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(120, 22);
            this.middleNameTextBox.TabIndex = 2;
            // 
            // titleFirstMiddleLastButton
            // 
            this.titleFirstMiddleLastButton.Location = new System.Drawing.Point(44, 297);
            this.titleFirstMiddleLastButton.Name = "titleFirstMiddleLastButton";
            this.titleFirstMiddleLastButton.Size = new System.Drawing.Size(136, 23);
            this.titleFirstMiddleLastButton.TabIndex = 4;
            this.titleFirstMiddleLastButton.Text = "Title First Middle Last";
            this.titleFirstMiddleLastButton.UseVisualStyleBackColor = true;
            this.titleFirstMiddleLastButton.Click += new System.EventHandler(this.titleFirstMiddleLastButton_Click);
            // 
            // firstMiddleLastButton
            // 
            this.firstMiddleLastButton.Location = new System.Drawing.Point(44, 343);
            this.firstMiddleLastButton.Name = "firstMiddleLastButton";
            this.firstMiddleLastButton.Size = new System.Drawing.Size(136, 23);
            this.firstMiddleLastButton.TabIndex = 5;
            this.firstMiddleLastButton.Text = "First Middle Last";
            this.firstMiddleLastButton.UseVisualStyleBackColor = true;
            this.firstMiddleLastButton.Click += new System.EventHandler(this.firstMiddleLastButton_Click);
            // 
            // firstLastButton
            // 
            this.firstLastButton.Location = new System.Drawing.Point(44, 385);
            this.firstLastButton.Name = "firstLastButton";
            this.firstLastButton.Size = new System.Drawing.Size(136, 23);
            this.firstLastButton.TabIndex = 6;
            this.firstLastButton.Text = "First Last";
            this.firstLastButton.UseVisualStyleBackColor = true;
            this.firstLastButton.Click += new System.EventHandler(this.firstLastButton_Click);
            // 
            // last_FirstMiddle_titleButton
            // 
            this.last_FirstMiddle_titleButton.Location = new System.Drawing.Point(233, 297);
            this.last_FirstMiddle_titleButton.Name = "last_FirstMiddle_titleButton";
            this.last_FirstMiddle_titleButton.Size = new System.Drawing.Size(137, 23);
            this.last_FirstMiddle_titleButton.TabIndex = 7;
            this.last_FirstMiddle_titleButton.Text = "Last, First Middle, Title";
            this.last_FirstMiddle_titleButton.UseVisualStyleBackColor = true;
            this.last_FirstMiddle_titleButton.Click += new System.EventHandler(this.last_FirstMiddle_titleButton_Click);
            // 
            // last_FirstMiddleButton
            // 
            this.last_FirstMiddleButton.Location = new System.Drawing.Point(233, 343);
            this.last_FirstMiddleButton.Name = "last_FirstMiddleButton";
            this.last_FirstMiddleButton.Size = new System.Drawing.Size(137, 23);
            this.last_FirstMiddleButton.TabIndex = 8;
            this.last_FirstMiddleButton.Text = "Last, First Middle";
            this.last_FirstMiddleButton.UseVisualStyleBackColor = true;
            this.last_FirstMiddleButton.Click += new System.EventHandler(this.last_FirstMiddleButton_Click);
            // 
            // last_FirstButton
            // 
            this.last_FirstButton.Location = new System.Drawing.Point(233, 385);
            this.last_FirstButton.Name = "last_FirstButton";
            this.last_FirstButton.Size = new System.Drawing.Size(137, 23);
            this.last_FirstButton.TabIndex = 9;
            this.last_FirstButton.Text = "Last, First";
            this.last_FirstButton.UseVisualStyleBackColor = true;
            this.last_FirstButton.Click += new System.EventHandler(this.last_FirstButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(404, 309);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(89, 38);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(404, 370);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(89, 38);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // chooseFormatLabel
            // 
            this.chooseFormatLabel.AutoSize = true;
            this.chooseFormatLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseFormatLabel.Location = new System.Drawing.Point(103, 255);
            this.chooseFormatLabel.Name = "chooseFormatLabel";
            this.chooseFormatLabel.Size = new System.Drawing.Size(316, 20);
            this.chooseFormatLabel.TabIndex = 21;
            this.chooseFormatLabel.Text = "Choose a format to display your name:";
            // 
            // yourNameLabel
            // 
            this.yourNameLabel.AutoSize = true;
            this.yourNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yourNameLabel.Location = new System.Drawing.Point(12, 464);
            this.yourNameLabel.Name = "yourNameLabel";
            this.yourNameLabel.Size = new System.Drawing.Size(101, 20);
            this.yourNameLabel.TabIndex = 22;
            this.yourNameLabel.Text = "Your name:";
            // 
            // nameOutputLabel
            // 
            this.nameOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameOutputLabel.Font = new System.Drawing.Font("Bodoni MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameOutputLabel.Location = new System.Drawing.Point(128, 450);
            this.nameOutputLabel.Name = "nameOutputLabel";
            this.nameOutputLabel.Size = new System.Drawing.Size(365, 44);
            this.nameOutputLabel.TabIndex = 0;
            this.nameOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // titleGroupBox
            // 
            this.titleGroupBox.Controls.Add(this.drRadio);
            this.titleGroupBox.Controls.Add(this.mrRadio);
            this.titleGroupBox.Controls.Add(this.mrsRadio);
            this.titleGroupBox.Controls.Add(this.msRadio);
            this.titleGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleGroupBox.Location = new System.Drawing.Point(63, 58);
            this.titleGroupBox.Name = "titleGroupBox";
            this.titleGroupBox.Size = new System.Drawing.Size(356, 42);
            this.titleGroupBox.TabIndex = 24;
            this.titleGroupBox.TabStop = false;
            this.titleGroupBox.Text = "Title";
            // 
            // drRadio
            // 
            this.drRadio.AutoSize = true;
            this.drRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drRadio.Location = new System.Drawing.Point(277, 14);
            this.drRadio.Name = "drRadio";
            this.drRadio.Size = new System.Drawing.Size(41, 19);
            this.drRadio.TabIndex = 3;
            this.drRadio.TabStop = true;
            this.drRadio.Text = "Dr.";
            this.drRadio.UseVisualStyleBackColor = true;
            this.drRadio.CheckedChanged += new System.EventHandler(this.drRadio_CheckedChanged);
            // 
            // mrRadio
            // 
            this.mrRadio.AutoSize = true;
            this.mrRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mrRadio.Location = new System.Drawing.Point(208, 14);
            this.mrRadio.Name = "mrRadio";
            this.mrRadio.Size = new System.Drawing.Size(43, 19);
            this.mrRadio.TabIndex = 2;
            this.mrRadio.TabStop = true;
            this.mrRadio.Text = "Mr.";
            this.mrRadio.UseVisualStyleBackColor = true;
            this.mrRadio.CheckedChanged += new System.EventHandler(this.mrRadio_CheckedChanged);
            // 
            // mrsRadio
            // 
            this.mrsRadio.AutoSize = true;
            this.mrsRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mrsRadio.Location = new System.Drawing.Point(119, 14);
            this.mrsRadio.Name = "mrsRadio";
            this.mrsRadio.Size = new System.Drawing.Size(49, 19);
            this.mrsRadio.TabIndex = 1;
            this.mrsRadio.TabStop = true;
            this.mrsRadio.Text = "Mrs.";
            this.mrsRadio.UseVisualStyleBackColor = true;
            this.mrsRadio.CheckedChanged += new System.EventHandler(this.mrsRadio_CheckedChanged);
            // 
            // msRadio
            // 
            this.msRadio.AutoSize = true;
            this.msRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msRadio.Location = new System.Drawing.Point(44, 14);
            this.msRadio.Name = "msRadio";
            this.msRadio.Size = new System.Drawing.Size(45, 19);
            this.msRadio.TabIndex = 0;
            this.msRadio.TabStop = true;
            this.msRadio.Text = "Ms.";
            this.msRadio.UseVisualStyleBackColor = true;
            this.msRadio.CheckedChanged += new System.EventHandler(this.msRadio_CheckedChanged);
            // 
            // nameFormatterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 526);
            this.Controls.Add(this.titleGroupBox);
            this.Controls.Add(this.nameOutputLabel);
            this.Controls.Add(this.yourNameLabel);
            this.Controls.Add(this.chooseFormatLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.last_FirstButton);
            this.Controls.Add(this.last_FirstMiddleButton);
            this.Controls.Add(this.last_FirstMiddle_titleButton);
            this.Controls.Add(this.firstLastButton);
            this.Controls.Add(this.firstMiddleLastButton);
            this.Controls.Add(this.titleFirstMiddleLastButton);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Name = "nameFormatterForm";
            this.Text = "Name Formatter";
            this.titleGroupBox.ResumeLayout(false);
            this.titleGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.Button titleFirstMiddleLastButton;
        private System.Windows.Forms.Button firstMiddleLastButton;
        private System.Windows.Forms.Button firstLastButton;
        private System.Windows.Forms.Button last_FirstMiddle_titleButton;
        private System.Windows.Forms.Button last_FirstMiddleButton;
        private System.Windows.Forms.Button last_FirstButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label chooseFormatLabel;
        private System.Windows.Forms.Label yourNameLabel;
        private System.Windows.Forms.Label nameOutputLabel;
        private System.Windows.Forms.GroupBox titleGroupBox;
        private System.Windows.Forms.RadioButton drRadio;
        private System.Windows.Forms.RadioButton mrRadio;
        private System.Windows.Forms.RadioButton mrsRadio;
        private System.Windows.Forms.RadioButton msRadio;
    }
}

