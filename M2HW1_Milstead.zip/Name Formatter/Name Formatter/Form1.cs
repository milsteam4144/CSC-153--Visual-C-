﻿/**
* 2/11/2018
* CSC 153
* Mallory Milstead
* This program accepts user input of their name and displays the name in multiple formats.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class nameFormatterForm : Form
    {
        private string firstName = "";
        private string middleName = "";
        private string lastName = "";
        private string title = "";

        public nameFormatterForm()
        {
            InitializeComponent();
        }

        private void msRadio_CheckedChanged(object sender, EventArgs e)
        {
            title = "Ms.";
        }

        private void mrsRadio_CheckedChanged(object sender, EventArgs e)
        {
            title = "Mrs.";
        }

        private void mrRadio_CheckedChanged(object sender, EventArgs e)
        {
            title = "Mr.";
        }

        private void drRadio_CheckedChanged(object sender, EventArgs e)
        {
            title = "Dr.";
        }


        private void firstMiddleLastButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = firstName + " " + middleName + " " + lastName;
           
        }

        private void firstLastButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = firstName + " "+ lastName;
        }

        private void last_FirstMiddleButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = lastName + "," + " " + firstName + " " + middleName;
        }

        private void last_FirstButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = lastName + "," + " " + firstName;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
           
            firstNameTextBox.Text = "";
            
            middleNameTextBox.Text = "";
            
            lastNameTextBox.Text = "";

            nameOutputLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void titleFirstMiddleLastButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = title + " " + firstName + " "+ middleName + " " + lastName;
            if (title != "Ms." & title != "Mrs." & title != "Mr." & title != "Dr.")
            { MessageBox.Show("Please enter a title."); }
        }

        private void last_FirstMiddle_titleButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            nameOutputLabel.Text = lastName + "," + " " + firstName + " " + middleName + "," + " " + title;
            if (title != "Ms." & title != "Mrs." & title != "Mr." & title != "Dr.")
            { MessageBox.Show("Please enter a title."); }
        }
    }
}
