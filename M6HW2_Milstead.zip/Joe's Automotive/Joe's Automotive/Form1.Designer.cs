﻿namespace Joe_s_Automotive
{
    partial class autoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.radiatorCheckBox = new System.Windows.Forms.CheckBox();
            this.oil_lubeGroupBox = new System.Windows.Forms.GroupBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.transCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.tireCheckBox = new System.Windows.Forms.CheckBox();
            this.mufflerCheckBox = new System.Windows.Forms.CheckBox();
            this.inspectionCheckBox = new System.Windows.Forms.CheckBox();
            this.partsGroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.laborTextBox = new System.Windows.Forms.TextBox();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.serviceTotalLabel = new System.Windows.Forms.Label();
            this.partsTotalLabel = new System.Windows.Forms.Label();
            this.taxTotalLabel = new System.Windows.Forms.Label();
            this.totalfeeLabel = new System.Windows.Forms.Label();
            this.oil_lubeGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.partsGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Location = new System.Drawing.Point(6, 28);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(120, 17);
            this.oilCheckBox.TabIndex = 0;
            this.oilCheckBox.Text = "Oil Change ($26.00)";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Location = new System.Drawing.Point(6, 51);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(112, 17);
            this.lubeCheckBox.TabIndex = 1;
            this.lubeCheckBox.Text = "Lube Job ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // radiatorCheckBox
            // 
            this.radiatorCheckBox.AutoSize = true;
            this.radiatorCheckBox.Location = new System.Drawing.Point(6, 28);
            this.radiatorCheckBox.Name = "radiatorCheckBox";
            this.radiatorCheckBox.Size = new System.Drawing.Size(136, 17);
            this.radiatorCheckBox.TabIndex = 2;
            this.radiatorCheckBox.Text = "Radiator Flush ($30.00)";
            this.radiatorCheckBox.UseVisualStyleBackColor = true;
            // 
            // oil_lubeGroupBox
            // 
            this.oil_lubeGroupBox.Controls.Add(this.oilCheckBox);
            this.oil_lubeGroupBox.Controls.Add(this.lubeCheckBox);
            this.oil_lubeGroupBox.Location = new System.Drawing.Point(12, 25);
            this.oil_lubeGroupBox.Name = "oil_lubeGroupBox";
            this.oil_lubeGroupBox.Size = new System.Drawing.Size(210, 83);
            this.oil_lubeGroupBox.TabIndex = 3;
            this.oil_lubeGroupBox.TabStop = false;
            this.oil_lubeGroupBox.Text = "Oil and Lube";
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.transCheckBox);
            this.flushesGroupBox.Controls.Add(this.radiatorCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(240, 25);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(220, 83);
            this.flushesGroupBox.TabIndex = 4;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // transCheckBox
            // 
            this.transCheckBox.AutoSize = true;
            this.transCheckBox.Location = new System.Drawing.Point(6, 51);
            this.transCheckBox.Name = "transCheckBox";
            this.transCheckBox.Size = new System.Drawing.Size(157, 17);
            this.transCheckBox.TabIndex = 3;
            this.transCheckBox.Text = "Transmission Flush ($80.00)";
            this.transCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.tireCheckBox);
            this.miscGroupBox.Controls.Add(this.mufflerCheckBox);
            this.miscGroupBox.Controls.Add(this.inspectionCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(12, 130);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(210, 100);
            this.miscGroupBox.TabIndex = 5;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc";
            // 
            // tireCheckBox
            // 
            this.tireCheckBox.AutoSize = true;
            this.tireCheckBox.Location = new System.Drawing.Point(6, 65);
            this.tireCheckBox.Name = "tireCheckBox";
            this.tireCheckBox.Size = new System.Drawing.Size(129, 17);
            this.tireCheckBox.TabIndex = 6;
            this.tireCheckBox.Text = "Tire Rotation ($20.00)";
            this.tireCheckBox.UseVisualStyleBackColor = true;
            // 
            // mufflerCheckBox
            // 
            this.mufflerCheckBox.AutoSize = true;
            this.mufflerCheckBox.Location = new System.Drawing.Point(6, 42);
            this.mufflerCheckBox.Name = "mufflerCheckBox";
            this.mufflerCheckBox.Size = new System.Drawing.Size(149, 17);
            this.mufflerCheckBox.TabIndex = 7;
            this.mufflerCheckBox.Text = "Replace Muffler ($100.00)";
            this.mufflerCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspectionCheckBox
            // 
            this.inspectionCheckBox.AutoSize = true;
            this.inspectionCheckBox.Location = new System.Drawing.Point(6, 19);
            this.inspectionCheckBox.Name = "inspectionCheckBox";
            this.inspectionCheckBox.Size = new System.Drawing.Size(117, 17);
            this.inspectionCheckBox.TabIndex = 8;
            this.inspectionCheckBox.Text = "Inspection ($15.00)";
            this.inspectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsGroupBox
            // 
            this.partsGroupBox.Controls.Add(this.label1);
            this.partsGroupBox.Controls.Add(this.label2);
            this.partsGroupBox.Controls.Add(this.laborTextBox);
            this.partsGroupBox.Controls.Add(this.partsTextBox);
            this.partsGroupBox.Location = new System.Drawing.Point(240, 130);
            this.partsGroupBox.Name = "partsGroupBox";
            this.partsGroupBox.Size = new System.Drawing.Size(220, 100);
            this.partsGroupBox.TabIndex = 0;
            this.partsGroupBox.TabStop = false;
            this.partsGroupBox.Text = "Parts and Labor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Parts";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Labor ($)";
            // 
            // laborTextBox
            // 
            this.laborTextBox.Location = new System.Drawing.Point(96, 65);
            this.laborTextBox.Name = "laborTextBox";
            this.laborTextBox.Size = new System.Drawing.Size(67, 20);
            this.laborTextBox.TabIndex = 9;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(96, 35);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(67, 20);
            this.partsTextBox.TabIndex = 10;
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.totalfeeLabel);
            this.summaryGroupBox.Controls.Add(this.taxTotalLabel);
            this.summaryGroupBox.Controls.Add(this.partsTotalLabel);
            this.summaryGroupBox.Controls.Add(this.serviceTotalLabel);
            this.summaryGroupBox.Controls.Add(this.label3);
            this.summaryGroupBox.Controls.Add(this.label4);
            this.summaryGroupBox.Controls.Add(this.label5);
            this.summaryGroupBox.Controls.Add(this.label6);
            this.summaryGroupBox.Location = new System.Drawing.Point(18, 259);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(432, 158);
            this.summaryGroupBox.TabIndex = 6;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Service and Labor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(81, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Parts";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Tax (on parts)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Total Fees";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(55, 423);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(92, 49);
            this.calculateButton.TabIndex = 7;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(198, 423);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(92, 49);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(336, 423);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(92, 49);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // serviceTotalLabel
            // 
            this.serviceTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.serviceTotalLabel.Location = new System.Drawing.Point(143, 32);
            this.serviceTotalLabel.Name = "serviceTotalLabel";
            this.serviceTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.serviceTotalLabel.TabIndex = 15;
            // 
            // partsTotalLabel
            // 
            this.partsTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsTotalLabel.Location = new System.Drawing.Point(143, 61);
            this.partsTotalLabel.Name = "partsTotalLabel";
            this.partsTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.partsTotalLabel.TabIndex = 16;
            // 
            // taxTotalLabel
            // 
            this.taxTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxTotalLabel.Location = new System.Drawing.Point(143, 87);
            this.taxTotalLabel.Name = "taxTotalLabel";
            this.taxTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.taxTotalLabel.TabIndex = 17;
            // 
            // totalfeeLabel
            // 
            this.totalfeeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalfeeLabel.Location = new System.Drawing.Point(143, 117);
            this.totalfeeLabel.Name = "totalfeeLabel";
            this.totalfeeLabel.Size = new System.Drawing.Size(100, 23);
            this.totalfeeLabel.TabIndex = 18;
            // 
            // autoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 482);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.partsGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.oil_lubeGroupBox);
            this.Name = "autoForm";
            this.Text = "Automotive";
            this.oil_lubeGroupBox.ResumeLayout(false);
            this.oil_lubeGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.partsGroupBox.ResumeLayout(false);
            this.partsGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.summaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.CheckBox radiatorCheckBox;
        private System.Windows.Forms.GroupBox oil_lubeGroupBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox transCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.GroupBox partsGroupBox;
        private System.Windows.Forms.CheckBox tireCheckBox;
        private System.Windows.Forms.CheckBox mufflerCheckBox;
        private System.Windows.Forms.CheckBox inspectionCheckBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox laborTextBox;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label totalfeeLabel;
        private System.Windows.Forms.Label taxTotalLabel;
        private System.Windows.Forms.Label partsTotalLabel;
        private System.Windows.Forms.Label serviceTotalLabel;
    }
}

