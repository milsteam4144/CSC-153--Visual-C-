﻿/**
* 4/12/2018
* CSC 153
* Mallory Milstead
* Program description
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_s_Automotive
{
    public partial class autoForm : Form
    {
        public autoForm()
        {
            InitializeComponent();
        }

        private decimal OilLubeCharges()
        {
            //Initialize variable.
            decimal oil_lubeCharges = 0m;

            //If statement assigns new value to variable if the checkbox is checked.
            if (oilCheckBox.Checked)
            {
                oil_lubeCharges += 26.00m;
            }

            //If statement assigns new value to variable if the checkbox is checked.
            if (lubeCheckBox.Checked)
             { 
               oil_lubeCharges += 18.00m;
             }

            //Return the value of the variable to the function.
            return oil_lubeCharges;
        }

        private decimal FlushCharges()
        {
            //Initialize the variable.
            decimal rad_transCharges = 0m;

            //If statement assigns new value to variable if the checkbox is checked.
            if (radiatorCheckBox.Checked)
            {
                rad_transCharges += 30.00m;
            }

            //If statement assigns new value to variable if the checkbox is checked.
            if (transCheckBox.Checked)
            {
                rad_transCharges += 80.00m;
            }
            
            //Return the value of the variable to the function.
            return rad_transCharges;
        }
        private decimal MiscCharges()
        {
            //Initalize the variable.
            decimal misc_Charges = 0m;

            //If statement assigns new value to variable if the checkbox is checked.
            if (inspectionCheckBox.Checked)
            {
                misc_Charges += 15.00m;
            }
            //If statement assigns new value to variable if the checkbox is checked.
            if (mufflerCheckBox.Checked)
            {
                misc_Charges += 100.00m;
            }
            //If statement assigns new value to variable if the checkbox is checked.
            if (tireCheckBox.Checked)
            {
                misc_Charges += 20.00m;
            }
            //Return the value of the variable to the function.
            return misc_Charges;

        }
        private decimal OtherCharges()
        {
            //If the value in the textbox can be parsed to a decimal, output the value to the variable.
            if (decimal.TryParse(partsTextBox.Text, out decimal partsCharge)) ;

            else { MessageBox.Show("Invalid parts cost entered."); }

            //If the value in the textbox can be parsed to a decimal, output the value to the variable.
            if (decimal.TryParse(laborTextBox.Text, out decimal laborCharge)) ;

            else { MessageBox.Show("Invalid labor cost entered."); }

            //Assign the total of the two variables to a new variable.
            decimal otherCharges = partsCharge + laborCharge;
            
            //Return the variable that contains the total.
            return otherCharges;

        }
        private decimal TaxCharges(decimal partsCharge)
        {
            //Calculate the value of the tax using the parameter(variable) partsCharge from the previous function.
            decimal tax = partsCharge * .06m;
            //Return the variable to the function.
            return tax;
        }
        private decimal TotalCharges(decimal oil_lubeCharges, decimal rad_transCharges, decimal misc_Charges, decimal otherCharges, decimal tax)
        {
            //Calculate the total of the charges using the parameters(variables) from the previous functions.
            decimal total = oil_lubeCharges + rad_transCharges + misc_Charges + otherCharges + tax;

            //Return the variable to the function.
            return total;
        }

        private void calculateButton_Click(object sender, EventArgs e)

        {
            //Assign the values returned from the functions to variables.
            decimal.TryParse(partsTextBox.Text, out decimal parts);
            decimal oil_lube = OilLubeCharges();
            decimal rad_trans = FlushCharges();
            decimal misc = MiscCharges();
            decimal other = OtherCharges();
            decimal tax = TaxCharges(parts);
            //Calculate the total.
            decimal total = TotalCharges(oil_lube, rad_trans, misc, other, tax);

            //Output the values to the form's labels.
            serviceTotalLabel.Text = (oil_lube + rad_trans + misc + other - parts).ToString("c");
            partsTotalLabel.Text = parts.ToString("c");
            taxTotalLabel.Text = tax.ToString("c");
            totalfeeLabel.Text = total.ToString("c");

        }

        private void ClearOilLube()
        {
            //Clear the checkboxes by assigning their .Checked value to false.
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }
        private void ClearFlushes()
        {
            //Clear the checkboxes by assigning their .Checked value to false.
            radiatorCheckBox.Checked = false;
            transCheckBox.Checked = false;
        }
        private void ClearMisc()
        {
            //Clear the checkboxes by assigning their .Checked value to false.
            inspectionCheckBox.Checked = false;
            mufflerCheckBox.Checked = false;
            tireCheckBox.Checked = false;
        }
        private void ClearOther()
        {
            //Clear the textboxes by assigning their value to an empty string.
            partsTextBox.Text = "";
            laborTextBox.Text = "";
        }
        private void ClearFees()
        {
            //Clear the textboxes by assigning their value to an empty string.
            serviceTotalLabel.Text = "";
            partsTotalLabel.Text = "";
            taxTotalLabel.Text = "";
            totalfeeLabel.Text = "";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Call the clear functions when the button is clicked.
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }




}
